# Proguard rules for WordCity
#
# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep Jetpack Compose annotations
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}

# Keep Kotlin Coroutines
-keepattributes *Annotation*, InnerClasses, EnclosingMethod

# Keep Room generated classes
-keep class * extends androidx.room.RoomDatabase

# Keep Hilt / Dagger generated classes
-dontwarn com.google.errorprone.annotations.**
