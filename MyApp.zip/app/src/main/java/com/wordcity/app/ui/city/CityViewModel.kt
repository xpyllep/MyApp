package com.wordcity.app.ui.city

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.data.local.entity.PlayerEntity
import com.wordcity.app.data.repository.BuildingRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.domain.model.BuildingType
import com.wordcity.app.domain.model.costForLevel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for the CityScreen.
 */
data class CityUiState(
    val player: PlayerEntity? = null,
    val buildings: List<BuildingEntity> = emptyList(),
    val totalIncome: Int = 0,
    val selectedCell: Pair<Int, Int>? = null,
    val selectedBuilding: BuildingEntity? = null,
    val isBuildingDialogOpen: Boolean = false,
    val isUpgradeDialogOpen: Boolean = false,
    val collectedIncomeAmount: Int? = null,
    val feedbackMessage: String? = null
)

/**
 * ViewModel managing the City grid, building construction, upgrades, and passive coin collection.
 */
@HiltViewModel
class CityViewModel @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val buildingRepository: BuildingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CityUiState())
    val uiState: StateFlow<CityUiState> = _uiState.asStateFlow()

    private val _snackMessage = MutableSharedFlow<String>()
    val snackMessage: SharedFlow<String> = _snackMessage.asSharedFlow()

    init {
        viewModelScope.launch {
            playerRepository.initializePlayer()
            playerRepository.updateLastPlayed()
        }

        viewModelScope.launch {
            combine(
                playerRepository.getPlayer(),
                buildingRepository.getAllBuildings()
            ) { player, buildings ->
                val income = buildingRepository.calculateIncome(buildings)
                _uiState.value.copy(
                    player = player,
                    buildings = buildings,
                    totalIncome = income
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    /**
     * Handles tapping on a grid cell (x, y).
     * If occupied, opens building details / upgrade dialog.
     * If empty, opens quick construction menu.
     */
    fun onCellClicked(gridX: Int, gridY: Int) {
        val buildingAtCell = _uiState.value.buildings.find { it.gridX == gridX && it.gridY == gridY }
        if (buildingAtCell != null) {
            _uiState.value = _uiState.value.copy(
                selectedCell = Pair(gridX, gridY),
                selectedBuilding = buildingAtCell,
                isUpgradeDialogOpen = true,
                isBuildingDialogOpen = false
            )
        } else {
            _uiState.value = _uiState.value.copy(
                selectedCell = Pair(gridX, gridY),
                selectedBuilding = null,
                isBuildingDialogOpen = true,
                isUpgradeDialogOpen = false
            )
        }
    }

    fun dismissDialogs() {
        _uiState.value = _uiState.value.copy(
            selectedCell = null,
            selectedBuilding = null,
            isBuildingDialogOpen = false,
            isUpgradeDialogOpen = false
        )
    }

    /**
     * Constructs a new building of [type] at currently selected cell.
     */
    fun purchaseBuilding(type: BuildingType) {
        val cell = _uiState.value.selectedCell ?: return
        val player = _uiState.value.player ?: return

        if (player.level < type.requiredLevel) {
            viewModelScope.launch {
                _snackMessage.emit("Требуется ${type.requiredLevel} уровень!")
            }
            return
        }

        val cost = type.baseCost
        if (player.coins < cost) {
            viewModelScope.launch {
                _snackMessage.emit("Недостаточно монет! Нужно: $cost 🪙")
            }
            return
        }

        viewModelScope.launch {
            val success = buildingRepository.purchaseBuilding(
                type = type.name,
                gridX = cell.first,
                gridY = cell.second,
                cost = cost
            )
            if (success) {
                _snackMessage.emit("${type.displayName} построен!")
                dismissDialogs()
            } else {
                _snackMessage.emit("Не удалось построить здание")
            }
        }
    }

    /**
     * Upgrades currently selected building to the next level.
     */
    fun upgradeCurrentBuilding() {
        val building = _uiState.value.selectedBuilding ?: return
        val type = BuildingType.fromString(building.type) ?: return
        val nextLevel = building.level + 1
        val cost = type.costForLevel(nextLevel)
        val player = _uiState.value.player ?: return

        if (player.coins < cost) {
            viewModelScope.launch {
                _snackMessage.emit("Недостаточно монет для улучшения! Нужно: $cost 🪙")
            }
            return
        }

        viewModelScope.launch {
            val success = buildingRepository.upgradeBuilding(building.id, cost)
            if (success) {
                _snackMessage.emit("${type.displayName} улучшен до уровня $nextLevel!")
                dismissDialogs()
            } else {
                _snackMessage.emit("Не удалось улучшить здание")
            }
        }
    }

    /**
     * Collects passive coin income generated by all buildings.
     */
    fun collectIncome() {
        val income = _uiState.value.totalIncome
        if (income <= 0) {
            viewModelScope.launch {
                _snackMessage.emit("Постройте здания, чтобы получать доход!")
            }
            return
        }

        viewModelScope.launch {
            playerRepository.addCoins(income)
            _uiState.value = _uiState.value.copy(collectedIncomeAmount = income)
            _snackMessage.emit("Собрано: +$income 🪙")
            delay(1500)
            _uiState.value = _uiState.value.copy(collectedIncomeAmount = null)
        }
    }
}
