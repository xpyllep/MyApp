package com.wordcity.app.data.repository

import com.wordcity.app.data.local.SeedData
import com.wordcity.app.data.local.dao.PlayerDao
import com.wordcity.app.data.local.entity.PlayerEntity
import com.wordcity.app.domain.model.xpForLevel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing player profile, currency, XP progression, streaks, and attendance.
 */
@Singleton
class PlayerRepository @Inject constructor(
    private val playerDao: PlayerDao
) {

    /**
     * Emits the current player state. Falls back to default player if database is initializing.
     */
    fun getPlayer(): Flow<PlayerEntity> {
        return playerDao.getPlayer().map { it ?: SeedData.getInitialPlayer() }
    }

    /**
     * Adds coins to the player's balance.
     */
    suspend fun addCoins(amount: Int) {
        playerDao.addCoins(amount)
    }

    /**
     * Attempts to deduct coins from player balance.
     * @return true if successful, false if balance was insufficient
     */
    suspend fun spendCoins(amount: Int): Boolean {
        val player = playerDao.getPlayerSync() ?: return false
        if (player.coins < amount) {
            return false
        }
        playerDao.addCoins(-amount)
        return true
    }

    /**
     * Adds XP and handles level-up thresholds.
     * @return the new level if a level-up occurred, or 0 if player did not level up
     */
    suspend fun addXp(amount: Int): Int {
        val player = playerDao.getPlayerSync() ?: return 0
        var currentXp = player.xp + amount
        var currentLevel = player.level
        val initialLevel = currentLevel

        while (currentXp >= xpForLevel(currentLevel)) {
            currentXp -= xpForLevel(currentLevel)
            currentLevel++
        }

        if (currentLevel != initialLevel) {
            playerDao.updatePlayer(
                player.copy(
                    xp = currentXp,
                    level = currentLevel
                )
            )
            return currentLevel
        } else {
            playerDao.addXp(amount)
            return 0
        }
    }

    /**
     * Updates quiz streak and counters for correct/incorrect answers.
     * @return the updated streak count
     */
    suspend fun updateStreak(correct: Boolean): Int {
        val player = playerDao.getPlayerSync() ?: return 0
        val newStreak: Int
        val newBestStreak: Int
        val totalCorrect: Int
        val totalIncorrect: Int

        if (correct) {
            newStreak = player.currentStreak + 1
            newBestStreak = maxOf(player.bestStreak, newStreak)
            totalCorrect = player.totalCorrect + 1
            totalIncorrect = player.totalIncorrect
        } else {
            newStreak = 0
            newBestStreak = player.bestStreak
            totalCorrect = player.totalCorrect
            totalIncorrect = player.totalIncorrect + 1
        }

        playerDao.updatePlayer(
            player.copy(
                currentStreak = newStreak,
                bestStreak = newBestStreak,
                totalCorrect = totalCorrect,
                totalIncorrect = totalIncorrect
            )
        )
        return newStreak
    }

    /**
     * Initializes player entity with default values if no player exists in the database.
     */
    suspend fun initializePlayer() {
        if (playerDao.getPlayerSync() == null) {
            playerDao.insertPlayer(SeedData.getInitialPlayer())
        }
    }

    /**
     * Increments total words learned counter.
     */
    suspend fun incrementWordsLearned() {
        val player = playerDao.getPlayerSync() ?: return
        playerDao.updatePlayer(
            player.copy(totalWordsLearned = player.totalWordsLearned + 1)
        )
    }

    /**
     * Updates player's chosen avatar identifier.
     */
    suspend fun updateAvatar(avatarId: Int) {
        val player = playerDao.getPlayerSync() ?: return
        playerDao.updatePlayer(player.copy(avatarId = avatarId))
    }

    /**
     * Tracks daily check-in and updates consecutive attendance days.
     */
    suspend fun updateLastPlayed() {
        val player = playerDao.getPlayerSync() ?: return
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = dateFormat.format(Date())

        if (player.lastPlayedDate == todayStr) {
            return
        }

        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStr = dateFormat.format(calendar.time)

        val newConsecutiveDays = if (player.lastPlayedDate == yesterdayStr) {
            player.consecutiveDays + 1
        } else {
            1
        }

        playerDao.updatePlayer(
            player.copy(
                lastPlayedDate = todayStr,
                consecutiveDays = newConsecutiveDays
            )
        )
    }
}
