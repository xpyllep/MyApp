package com.wordcity.app.data.repository

import com.wordcity.app.data.local.SeedData
import com.wordcity.app.data.local.dao.WordDao
import com.wordcity.app.data.local.entity.WordEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository handling vocabulary word retrieval, progress updates, and quiz data preparation.
 */
@Singleton
class WordRepository @Inject constructor(
    private val wordDao: WordDao
) {

    /**
     * Retrieves all words belonging to a specific category.
     */
    fun getWordsByCategory(category: String): Flow<List<WordEntity>> {
        return wordDao.getWordsByCategory(category)
    }

    /**
     * Retrieves a random word from the specified category to serve as quiz question.
     */
    suspend fun getRandomWordForQuiz(category: String): WordEntity? {
        return wordDao.getRandomWord(category)
    }

    /**
     * Retrieves random distractor options from the same category excluding the correct word.
     */
    suspend fun getRandomWordsForQuiz(
        category: String,
        correctWordId: Int,
        count: Int = 3
    ): List<WordEntity> {
        return wordDao.getRandomWordsForQuiz(category, correctWordId, count)
    }

    /**
     * Updates word repetition statistics after a quiz attempt.
     * Marks the word as learned if correctCount >= 3.
     */
    suspend fun updateWordStats(wordId: Int, correct: Boolean) {
        val word = wordDao.getWordById(wordId) ?: return
        val newCorrect = if (correct) word.correctCount + 1 else word.correctCount
        val newIncorrect = if (!correct) word.incorrectCount + 1 else word.incorrectCount
        val isLearned = word.learned || (newCorrect >= 3)

        val updated = word.copy(
            correctCount = newCorrect,
            incorrectCount = newIncorrect,
            learned = isLearned,
            lastShownAt = System.currentTimeMillis()
        )
        wordDao.updateWord(updated)
    }

    /**
     * Flow of all mastered words.
     */
    fun getLearnedWords(): Flow<List<WordEntity>> {
        return wordDao.getLearnedWords()
    }

    /**
     * Flow of words that need review (answered correctly before but not yet mastered).
     */
    fun getWordsForReview(): Flow<List<WordEntity>> {
        return wordDao.getWordsForReview()
    }

    /**
     * Flow emitting the total number of mastered words.
     */
    fun getTotalLearnedCount(): Flow<Int> {
        return wordDao.getTotalLearnedCount()
    }

    /**
     * Flow emitting the full list of words in the database.
     */
    fun getAllWords(): Flow<List<WordEntity>> {
        return wordDao.getAllWords()
    }

    /**
     * Pre-populates the database with initial words if empty.
     */
    suspend fun initializeWordsIfEmpty() {
        if (wordDao.getWordCount() == 0) {
            wordDao.insertWords(SeedData.getInitialWords())
        }
    }
}
