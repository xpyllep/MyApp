package com.wordcity.app.ui.game

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProgressIndicatorDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordcity.app.domain.model.WordCategory
import com.wordcity.app.ui.components.CoinDisplay
import com.wordcity.app.ui.components.StreakIndicator
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.CoinGoldDark
import com.wordcity.app.ui.theme.CorrectGreen
import com.wordcity.app.ui.theme.CorrectGreenLight
import com.wordcity.app.ui.theme.IncorrectRed
import com.wordcity.app.ui.theme.IncorrectRedLight
import com.wordcity.app.ui.theme.PrimaryBlue
import com.wordcity.app.ui.theme.PrimaryBlueDark
import com.wordcity.app.ui.theme.SecondaryOrange
import com.wordcity.app.ui.theme.SkyGradientEnd
import com.wordcity.app.ui.theme.SkyGradientStart
import com.wordcity.app.ui.theme.TimerGreen
import com.wordcity.app.ui.theme.TimerRed
import com.wordcity.app.ui.theme.TimerYellow
import com.wordcity.app.ui.theme.XpPurple
import com.wordcity.app.ui.theme.XpPurpleDark
import kotlinx.coroutines.delay

/**
 * Quiz game screen with animated questions, countdown timer, multiple-choice options,
 * dynamic feedback, streak bonuses, and results breakdown.
 */
@Composable
fun GameScreen(
    onNavigateBack: () -> Unit,
    onNavigateToCity: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: GameViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            SkyGradientStart.copy(alpha = 0.8f),
                            SkyGradientEnd,
                            Color(0xFFEDE7F6)
                        )
                    )
                )
                .padding(paddingValues)
        ) {
            when {
                uiState.showResults -> {
                    ResultsView(
                        questionsAnswered = uiState.questionsAnswered,
                        correctAnswers = uiState.correctAnswers,
                        totalCoins = uiState.totalCoinsEarned,
                        totalXp = uiState.totalXpEarned,
                        bestStreak = uiState.bestStreak,
                        onPlayAgain = { viewModel.restartQuiz() },
                        onChangeCategory = { viewModel.openCategoryPicker() },
                        onGoToCity = onNavigateToCity
                    )
                }

                else -> {
                    GameQuizView(
                        uiState = uiState,
                        onAnswerSelected = { option -> viewModel.onAnswerSelected(option) },
                        onBackClick = onNavigateBack,
                        onOpenCategories = { viewModel.openCategoryPicker() }
                    )
                }
            }

            // Category Selection Dialog
            if (uiState.showCategoryPicker) {
                CategorySelectionDialog(
                    playerLevel = uiState.playerLevel,
                    onSelectCategory = { category -> viewModel.selectCategory(category) },
                    onDismiss = {
                        if (uiState.currentWord != null) {
                            // If a game was in progress, dismiss back to game
                            viewModel.restartQuiz()
                        } else {
                            onNavigateBack()
                        }
                    }
                )
            }
        }
    }
}

/**
 * Active Quiz gameplay view.
 */
@Composable
private fun GameQuizView(
    uiState: GameUiState,
    onAnswerSelected: (String) -> Unit,
    onBackClick: () -> Unit,
    onOpenCategories: () -> Unit
) {
    // Shake animation for incorrect answer
    val shakeOffset = remember { Animatable(0f) }
    LaunchedEffect(uiState.isCorrect) {
        if (uiState.isCorrect == false) {
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 400
                    -20f at 50
                    20f at 100
                    -15f at 150
                    15f at 200
                    -8f at 250
                    8f at 300
                    0f at 400
                }
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP: Header with Back, Category, Streak, Coins
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.9f))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            // Category Chip Button
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White.copy(alpha = 0.9f),
                shadowElevation = 2.dp,
                modifier = Modifier.clickable { onOpenCategories() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uiState.selectedCategory?.emoji ?: "📚",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = uiState.selectedCategory?.displayName ?: "Все слова",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlueDark
                        )
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StreakIndicator(streak = uiState.streak)
                CoinDisplay(coins = uiState.playerCoins)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Timer & Question Counter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Вопрос ${uiState.questionsAnswered + 1}/10",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )

            CircularTimer(
                timeRemaining = uiState.timeRemaining,
                totalTime = 15
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // CENTER: Word Card with Russian translation to guess
        Box(
            modifier = Modifier
                .offset { IntOffset(shakeOffset.value.toInt(), 0) }
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 8.dp, shape = RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Как переводится?",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = uiState.currentWord?.russian ?: "...",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Feedback on correct/incorrect
                    AnimatedVisibility(
                        visible = uiState.isAnswered,
                        enter = fadeIn() + scaleIn(),
                        exit = fadeOut()
                    ) {
                        if (uiState.isCorrect == true) {
                            Text(
                                text = "🎉 Верно! +${uiState.coinsEarned} 🪙  +${uiState.xpEarned} XP",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CorrectGreen
                                )
                            )
                        } else {
                            Text(
                                text = "❌ Ошибка! Правильно: ${uiState.currentWord?.english ?: ""}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = IncorrectRed
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // BOTTOM: 2x2 Answer Buttons Grid
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            for (rowIndex in 0..1) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (colIndex in 0..1) {
                        val optionIndex = rowIndex * 2 + colIndex
                        val optionText = uiState.options.getOrNull(optionIndex) ?: ""

                        AnswerButton(
                            option = optionText,
                            isAnswered = uiState.isAnswered,
                            isCorrectAnswer = optionText.equals(uiState.currentWord?.english, ignoreCase = true),
                            isSelected = optionText == uiState.selectedOption,
                            onClick = { onAnswerSelected(optionText) },
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}

/**
 * Circular countdown timer showing remaining seconds with color transition.
 */
@Composable
private fun CircularTimer(
    timeRemaining: Int,
    totalTime: Int = 15
) {
    val progress = timeRemaining.toFloat() / totalTime.toFloat()

    val timerColor by animateColorAsState(
        targetValue = when {
            timeRemaining > 8 -> TimerGreen
            timeRemaining > 4 -> TimerYellow
            else -> TimerRed
        },
        label = "TimerColor"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(46.dp)
    ) {
        CircularProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxSize(),
            color = timerColor,
            strokeWidth = 4.dp,
            trackColor = Color.White.copy(alpha = 0.5f)
        )
        Text(
            text = "$timeRemaining",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = timerColor
            )
        )
    }
}

/**
 * Styled multiple choice button with color-coded feedback states.
 */
@Composable
private fun AnswerButton(
    option: String,
    isAnswered: Boolean,
    isCorrectAnswer: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when {
        !isAnswered -> Color.White
        isCorrectAnswer -> CorrectGreen
        isSelected -> IncorrectRed
        else -> Color.White.copy(alpha = 0.6f)
    }

    val contentColor = when {
        !isAnswered -> MaterialTheme.colorScheme.onSurface
        isCorrectAnswer || isSelected -> Color.White
        else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
    }

    val borderColor = when {
        !isAnswered -> Color(0xFFE0E0E0)
        isCorrectAnswer -> CorrectGreen
        isSelected -> IncorrectRed
        else -> Color.Transparent
    }

    Surface(
        modifier = modifier
            .shadow(
                elevation = if (!isAnswered) 3.dp else 1.dp,
                shape = RoundedCornerShape(16.dp)
            )
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = !isAnswered) { onClick() },
        color = backgroundColor,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = option,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = contentColor
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

/**
 * Results view shown after completing 10 questions.
 */
@Composable
private fun ResultsView(
    questionsAnswered: Int,
    correctAnswers: Int,
    totalCoins: Int,
    totalXp: Int,
    bestStreak: Int,
    onPlayAgain: () -> Unit,
    onChangeCategory: () -> Unit,
    onGoToCity: () -> Unit
) {
    val accuracy = if (questionsAnswered > 0) (correctAnswers.toFloat() / questionsAnswered.toFloat()) else 0f
    val starsCount = when {
        accuracy >= 0.8f -> 3
        accuracy >= 0.5f -> 2
        else -> 1
    }

    val starScale1 = remember { Animatable(0f) }
    val starScale2 = remember { Animatable(0f) }
    val starScale3 = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        delay(200)
        starScale1.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
        if (starsCount >= 2) {
            delay(150)
            starScale2.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
        }
        if (starsCount >= 3) {
            delay(150)
            starScale3.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (starsCount == 3) "🏆 Отлично!" else if (starsCount == 2) "👍 Хорошо!" else "💪 Старайся!",
            style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Star Rating (1 to 3)
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StarBadge(scale = starScale1.value, active = starsCount >= 1)
            StarBadge(scale = starScale2.value, active = starsCount >= 2, isCenter = true)
            StarBadge(scale = starScale3.value, active = starsCount >= 3)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ResultRow(label = "Правильных ответов", value = "$correctAnswers из $questionsAnswered", emoji = "🎯")
                ResultRow(label = "Заработано монет", value = "+$totalCoins 🪙", emoji = "🪙", valueColor = CoinGoldDark)
                ResultRow(label = "Заработано опыта", value = "+$totalXp XP", emoji = "✨", valueColor = XpPurpleDark)
                ResultRow(label = "Лучшая серия", value = "$bestStreak 🔥", emoji = "🔥", valueColor = SecondaryOrange)
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Action Buttons
        Button(
            onClick = onPlayAgain,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(27.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Играть ещё", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onChangeCategory,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(27.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SecondaryOrange)
        ) {
            Icon(Icons.Filled.Category, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Выбрать другую категорию", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
            onClick = onGoToCity,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("В город", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
        }
    }
}

@Composable
private fun StarBadge(
    scale: Float,
    active: Boolean,
    isCenter: Boolean = false
) {
    val size = if (isCenter) 54.dp else 44.dp
    Icon(
        imageVector = Icons.Filled.Star,
        contentDescription = null,
        tint = if (active) CoinGold else Color(0xFFE0E0E0),
        modifier = Modifier
            .size(size)
            .scale(scale)
    )
}

@Composable
private fun ResultRow(
    label: String,
    value: String,
    emoji: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = emoji, fontSize = 20.sp, modifier = Modifier.padding(end = 8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = valueColor
            )
        )
    }
}

/**
 * Dialog for selecting a category to quiz on.
 */
@Composable
private fun CategorySelectionDialog(
    playerLevel: Int,
    onSelectCategory: (WordCategory) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🎯 Выберите тему",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(WordCategory.entries) { category ->
                    val isUnlocked = playerLevel >= category.requiredLevel
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = isUnlocked) { onSelectCategory(category) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUnlocked) {
                                Color(category.districtColor).copy(alpha = 0.15f)
                            } else {
                                Color(0xFFEEEEEE)
                            }
                        ),
                        border = if (isUnlocked) {
                            androidx.compose.foundation.BorderStroke(1.dp, Color(category.districtColor).copy(alpha = 0.4f))
                        } else null
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (isUnlocked) {
                                Text(text = category.emoji, fontSize = 32.sp)
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "Заблокировано",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = category.displayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else Color.Gray
                                ),
                                textAlign = TextAlign.Center
                            )
                            if (!isUnlocked) {
                                Text(
                                    text = "С уровня ${category.requiredLevel}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
