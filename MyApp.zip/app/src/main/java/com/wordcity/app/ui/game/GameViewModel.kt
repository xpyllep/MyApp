package com.wordcity.app.ui.game

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordcity.app.data.local.entity.WordEntity
import com.wordcity.app.data.repository.AchievementRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.data.repository.WordRepository
import com.wordcity.app.domain.model.WordCategory
import com.wordcity.app.ui.components.getStreakMultiplier
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val QUESTIONS_PER_SESSION = 10
private const val QUESTION_TIME_LIMIT_SECONDS = 15

/**
 * UI State for the Quiz Game screen.
 */
data class GameUiState(
    val currentWord: WordEntity? = null,
    val options: List<String> = emptyList(),
    val selectedOption: String? = null,
    val streak: Int = 0,
    val streakMultiplier: Float = 1.0f,
    val isAnswered: Boolean = false,
    val isCorrect: Boolean? = null,
    val coinsEarned: Int = 0,
    val xpEarned: Int = 0,
    val totalCoinsEarned: Int = 0,
    val totalXpEarned: Int = 0,
    val questionsAnswered: Int = 0,
    val correctAnswers: Int = 0,
    val bestStreak: Int = 0,
    val selectedCategory: WordCategory? = null,
    val showCategoryPicker: Boolean = true,
    val showResults: Boolean = false,
    val timeRemaining: Int = QUESTION_TIME_LIMIT_SECONDS,
    val playerCoins: Int = 0,
    val playerLevel: Int = 1
)

/**
 * ViewModel governing game quiz state, countdown timers, streak progression,
 * scoring calculations, and database statistics synchronizations.
 */
@HiltViewModel
class GameViewModel @Inject constructor(
    private val wordRepository: WordRepository,
    private val playerRepository: PlayerRepository,
    private val achievementRepository: AchievementRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var transitionJob: Job? = null

    init {
        viewModelScope.launch {
            wordRepository.initializeWordsIfEmpty()
            achievementRepository.initializeAchievements()
        }

        viewModelScope.launch {
            playerRepository.getPlayer().collect { player ->
                _uiState.value = _uiState.value.copy(
                    playerCoins = player.coins,
                    playerLevel = player.level,
                    streak = if (!_uiState.value.isAnswered && _uiState.value.questionsAnswered == 0) {
                        player.currentStreak
                    } else {
                        _uiState.value.streak
                    }
                )
            }
        }

        val categoryArg: String? = savedStateHandle["category"]
        if (!categoryArg.isNullOrBlank() && categoryArg != "ALL") {
            val matchedCategory = WordCategory.fromString(categoryArg)
            if (matchedCategory != null) {
                selectCategory(matchedCategory)
            }
        }
    }

    /**
     * Sets the quiz category and begins the first question.
     */
    fun selectCategory(category: WordCategory) {
        timerJob?.cancel()
        transitionJob?.cancel()

        _uiState.value = _uiState.value.copy(
            selectedCategory = category,
            showCategoryPicker = false,
            showResults = false,
            questionsAnswered = 0,
            correctAnswers = 0,
            totalCoinsEarned = 0,
            totalXpEarned = 0,
            bestStreak = _uiState.value.streak,
            streakMultiplier = getStreakMultiplier(_uiState.value.streak)
        )

        loadNextQuestion()
    }

    /**
     * Loads the next quiz question and sets up 4 multiple-choice options.
     */
    private fun loadNextQuestion() {
        if (_uiState.value.questionsAnswered >= QUESTIONS_PER_SESSION) {
            timerJob?.cancel()
            _uiState.value = _uiState.value.copy(showResults = true)
            return
        }

        viewModelScope.launch {
            val category = _uiState.value.selectedCategory ?: WordCategory.FOOD
            val word = wordRepository.getRandomWordForQuiz(category.name)

            if (word == null) {
                // Fallback: pick any word from the repository
                val allWords = wordRepository.getAllWords().firstOrNull() ?: emptyList()
                if (allWords.isNotEmpty()) {
                    setupQuestionWithOptions(allWords.random(), allWords)
                } else {
                    _uiState.value = _uiState.value.copy(showResults = true)
                }
                return@launch
            }

            val distractors = wordRepository.getRandomWordsForQuiz(
                category = category.name,
                correctWordId = word.id,
                count = 3
            )

            val fullOptionList = (distractors.map { it.english } + word.english).distinct().shuffled()
            val finalOptions = if (fullOptionList.size < 4) {
                // Add fallback words if category has fewer than 4 items
                val fallbackWords = wordRepository.getAllWords().firstOrNull() ?: emptyList()
                val additional = fallbackWords
                    .filter { it.english != word.english && it.english !in fullOptionList }
                    .take(4 - fullOptionList.size)
                    .map { it.english }
                (fullOptionList + additional).shuffled()
            } else {
                fullOptionList
            }

            _uiState.value = _uiState.value.copy(
                currentWord = word,
                options = finalOptions,
                selectedOption = null,
                isAnswered = false,
                isCorrect = null,
                coinsEarned = 0,
                xpEarned = 0,
                timeRemaining = QUESTION_TIME_LIMIT_SECONDS
            )

            startCountdownTimer()
        }
    }

    private fun setupQuestionWithOptions(word: WordEntity, allWords: List<WordEntity>) {
        val distractors = allWords.filter { it.id != word.id }.shuffled().take(3)
        val options = (distractors.map { it.english } + word.english).shuffled()

        _uiState.value = _uiState.value.copy(
            currentWord = word,
            options = options,
            selectedOption = null,
            isAnswered = false,
            isCorrect = null,
            coinsEarned = 0,
            xpEarned = 0,
            timeRemaining = QUESTION_TIME_LIMIT_SECONDS
        )

        startCountdownTimer()
    }

    /**
     * Starts the 15-second per-question timer.
     */
    private fun startCountdownTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            for (sec in QUESTION_TIME_LIMIT_SECONDS downTo 1) {
                _uiState.value = _uiState.value.copy(timeRemaining = sec)
                delay(1000)
            }
            _uiState.value = _uiState.value.copy(timeRemaining = 0)
            if (!_uiState.value.isAnswered) {
                // Timeout counts as incorrect answer
                onAnswerSelected(null)
            }
        }
    }

    /**
     * Handles selection of an answer by English string.
     */
    fun onAnswerSelected(selectedEnglish: String?) {
        if (_uiState.value.isAnswered) return

        timerJob?.cancel()

        val currentWord = _uiState.value.currentWord ?: return
        val isCorrect = selectedEnglish != null && selectedEnglish.equals(currentWord.english, ignoreCase = true)

        val currentStreak = _uiState.value.streak
        val newStreak = if (isCorrect) currentStreak + 1 else 0
        val multiplier = getStreakMultiplier(newStreak)
        val coinsWon = if (isCorrect) (10 * multiplier).toInt() else 0
        val xpWon = if (isCorrect) 15 else 5

        val updatedQuestionsAnswered = _uiState.value.questionsAnswered + 1
        val updatedCorrectAnswers = if (isCorrect) _uiState.value.correctAnswers + 1 else _uiState.value.correctAnswers
        val updatedBestStreak = maxOf(_uiState.value.bestStreak, newStreak)

        _uiState.value = _uiState.value.copy(
            isAnswered = true,
            isCorrect = isCorrect,
            selectedOption = selectedEnglish,
            streak = newStreak,
            streakMultiplier = multiplier,
            bestStreak = updatedBestStreak,
            coinsEarned = coinsWon,
            xpEarned = xpWon,
            totalCoinsEarned = _uiState.value.totalCoinsEarned + coinsWon,
            totalXpEarned = _uiState.value.totalXpEarned + xpWon,
            questionsAnswered = updatedQuestionsAnswered,
            correctAnswers = updatedCorrectAnswers
        )

        viewModelScope.launch {
            if (coinsWon > 0) {
                playerRepository.addCoins(coinsWon)
            }
            playerRepository.addXp(xpWon)
            playerRepository.updateStreak(isCorrect)
            wordRepository.updateWordStats(currentWord.id, isCorrect)

            // Update achievements
            if (newStreak >= 5) {
                achievementRepository.updateProgress("streak_5", newStreak)
            }
            if (newStreak >= 10) {
                achievementRepository.updateProgress("streak_10", newStreak)
            }
            achievementRepository.incrementProgress("words_learned", 1)
        }

        // Delay 1 second to show color feedback, then transition
        transitionJob = viewModelScope.launch {
            delay(1000)
            loadNextQuestion()
        }
    }

    /**
     * Restarts quiz session with current category.
     */
    fun restartQuiz() {
        val category = _uiState.value.selectedCategory ?: WordCategory.FOOD
        selectCategory(category)
    }

    /**
     * Opens category selector dialog.
     */
    fun openCategoryPicker() {
        timerJob?.cancel()
        transitionJob?.cancel()
        _uiState.value = _uiState.value.copy(
            showCategoryPicker = true,
            showResults = false
        )
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        transitionJob?.cancel()
    }
}
