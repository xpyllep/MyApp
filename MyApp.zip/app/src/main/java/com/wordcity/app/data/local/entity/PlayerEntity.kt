package com.wordcity.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing the player's profile, statistics, coins, and progression.
 *
 * @property id Singleton primary key (always 1 for the local player)
 * @property name Player's display name
 * @property avatarId Identifier for the chosen avatar asset
 * @property coins Available currency to construct and upgrade buildings
 * @property xp Current experience points earned
 * @property level Player level
 * @property currentStreak Current consecutive correct answers in quizzes
 * @property bestStreak Highest streak of correct answers achieved
 * @property totalCorrect Lifetime count of correct quiz answers
 * @property totalIncorrect Lifetime count of incorrect quiz answers
 * @property totalWordsLearned Total number of words mastered
 * @property consecutiveDays Number of consecutive days the player has practiced
 * @property lastPlayedDate ISO date string (YYYY-MM-DD) of the last practice session
 */
@Entity(tableName = "player")
data class PlayerEntity(
    @PrimaryKey
    val id: Int = 1,
    val name: String = "Игрок",
    val avatarId: Int = 0,
    val coins: Int = 500,
    val xp: Int = 0,
    val level: Int = 1,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val totalCorrect: Int = 0,
    val totalIncorrect: Int = 0,
    val totalWordsLearned: Int = 0,
    val consecutiveDays: Int = 0,
    val lastPlayedDate: String = ""
)
