package com.wordcity.app.data.repository

import com.wordcity.app.data.local.dao.BuildingDao
import com.wordcity.app.data.local.dao.PlayerDao
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.domain.model.BuildingType
import com.wordcity.app.domain.model.incomeForLevel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing city buildings, construction, upgrades, and grid validation.
 */
@Singleton
class BuildingRepository @Inject constructor(
    private val buildingDao: BuildingDao,
    private val playerDao: PlayerDao
) {

    /**
     * Flow of all constructed buildings.
     */
    fun getAllBuildings(): Flow<List<BuildingEntity>> {
        return buildingDao.getAllBuildings()
    }

    /**
     * Checks if a grid position is occupied.
     */
    suspend fun isCellOccupied(gridX: Int, gridY: Int): Boolean {
        return buildingDao.getBuildingAt(gridX, gridY) != null
    }

    /**
     * Purchases and constructs a new building at the given grid coordinates.
     *
     * @param type BuildingType string key
     * @param gridX X-coordinate on the district grid
     * @param gridY Y-coordinate on the district grid
     * @param cost Coin cost required to build
     * @return true if purchase and placement succeeded, false otherwise
     */
    suspend fun purchaseBuilding(
        type: String,
        gridX: Int,
        gridY: Int,
        cost: Int
    ): Boolean {
        if (isCellOccupied(gridX, gridY)) {
            return false
        }

        val player = playerDao.getPlayerSync() ?: return false
        if (player.coins < cost) {
            return false
        }

        playerDao.addCoins(-cost)

        val newBuilding = BuildingEntity(
            type = type,
            level = 1,
            gridX = gridX,
            gridY = gridY,
            purchasedAt = System.currentTimeMillis()
        )
        buildingDao.insertBuilding(newBuilding)
        return true
    }

    /**
     * Upgrades an existing building to its next level.
     *
     * @param buildingId Identifier of the building to upgrade
     * @param cost Coin cost required for the upgrade
     * @return true if upgraded successfully, false otherwise
     */
    suspend fun upgradeBuilding(buildingId: Int, cost: Int): Boolean {
        val building = buildingDao.getBuildingById(buildingId) ?: return false
        val player = playerDao.getPlayerSync() ?: return false

        if (player.coins < cost) {
            return false
        }

        playerDao.addCoins(-cost)
        buildingDao.updateBuilding(building.copy(level = building.level + 1))
        return true
    }

    /**
     * Flow of total number of buildings in the city.
     */
    fun getBuildingCount(): Flow<Int> {
        return buildingDao.getBuildingCount()
    }

    /**
     * Retrieves the building placed at a specific cell, or null if cell is empty.
     */
    suspend fun getBuildingAt(gridX: Int, gridY: Int): BuildingEntity? {
        return buildingDao.getBuildingAt(gridX, gridY)
    }

    /**
     * Calculates the total passive coin income generated across all constructed buildings.
     */
    fun calculateIncome(buildings: List<BuildingEntity>): Int {
        return buildings.sumOf { entity ->
            val type = BuildingType.fromString(entity.type) ?: return@sumOf 0
            type.incomeForLevel(entity.level)
        }
    }
}
