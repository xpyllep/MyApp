package com.wordcity.app.data.local

import com.wordcity.app.data.local.entity.AchievementEntity
import com.wordcity.app.data.local.entity.PlayerEntity
import com.wordcity.app.data.local.entity.WordEntity
import com.wordcity.app.domain.model.Achievement
import com.wordcity.app.domain.model.WordCategory

/**
 * Pre-populated seed data for WordCity app initialization.
 */
object SeedData {

    /**
     * Default starting player entity.
     */
    fun getInitialPlayer(): PlayerEntity = PlayerEntity(
        id = 1,
        name = "Игрок",
        avatarId = 0,
        coins = 500,
        xp = 0,
        level = 1,
        currentStreak = 0,
        bestStreak = 0,
        totalCorrect = 0,
        totalIncorrect = 0,
        totalWordsLearned = 0,
        consecutiveDays = 0,
        lastPlayedDate = ""
    )

    /**
     * Predefined initial achievements mapped to entities.
     */
    fun getInitialAchievements(): List<AchievementEntity> = Achievement.PREDEFINED_ACHIEVEMENTS.map {
        AchievementEntity(
            id = it.id,
            name = it.name,
            description = it.description,
            emoji = it.emoji,
            unlocked = false,
            unlockedAt = 0L,
            progress = 0,
            target = it.target
        )
    }

    /**
     * Over 300 English-Russian vocabulary pairs categorized into 9 themes.
     */
    fun getInitialWords(): List<WordEntity> {
        val words = mutableListOf<WordEntity>()

        fun addCategoryWords(category: WordCategory, pairs: List<Pair<String, String>>) {
            pairs.forEach { (english, russian) ->
                words.add(
                    WordEntity(
                        english = english,
                        russian = russian,
                        category = category.name,
                        learned = false,
                        correctCount = 0,
                        incorrectCount = 0,
                        lastShownAt = 0L
                    )
                )
            }
        }

        // FOOD (40 words)
        addCategoryWords(
            WordCategory.FOOD,
            listOf(
                "apple" to "яблоко",
                "bread" to "хлеб",
                "butter" to "масло",
                "cheese" to "сыр",
                "chicken" to "курица",
                "coffee" to "кофе",
                "egg" to "яйцо",
                "fish" to "рыба",
                "fruit" to "фрукт",
                "juice" to "сок",
                "meat" to "мясо",
                "milk" to "молоко",
                "orange" to "апельсин",
                "potato" to "картошка",
                "rice" to "рис",
                "salt" to "соль",
                "sugar" to "сахар",
                "tea" to "чай",
                "tomato" to "помидор",
                "water" to "вода",
                "banana" to "банан",
                "cake" to "торт",
                "candy" to "конфета",
                "carrot" to "морковь",
                "cookie" to "печенье",
                "corn" to "кукуруза",
                "cream" to "сливки",
                "grape" to "виноград",
                "honey" to "мёд",
                "ice cream" to "мороженое",
                "lemon" to "лимон",
                "mushroom" to "гриб",
                "nut" to "орех",
                "onion" to "лук",
                "pasta" to "паста",
                "pepper" to "перец",
                "pie" to "пирог",
                "pizza" to "пицца",
                "salad" to "салат",
                "soup" to "суп"
            )
        )

        // NATURE (40 words)
        addCategoryWords(
            WordCategory.NATURE,
            listOf(
                "cloud" to "облако",
                "earth" to "земля",
                "fire" to "огонь",
                "flower" to "цветок",
                "forest" to "лес",
                "grass" to "трава",
                "hill" to "холм",
                "island" to "остров",
                "lake" to "озеро",
                "leaf" to "лист",
                "moon" to "луна",
                "mountain" to "гора",
                "ocean" to "океан",
                "rain" to "дождь",
                "river" to "река",
                "rock" to "скала",
                "sand" to "песок",
                "sea" to "море",
                "sky" to "небо",
                "snow" to "снег",
                "star" to "звезда",
                "stone" to "камень",
                "storm" to "шторм",
                "sun" to "солнце",
                "tree" to "дерево",
                "valley" to "долина",
                "volcano" to "вулкан",
                "wave" to "волна",
                "weather" to "погода",
                "wind" to "ветер",
                "beach" to "пляж",
                "desert" to "пустыня",
                "garden" to "сад",
                "ice" to "лёд",
                "jungle" to "джунгли",
                "rainbow" to "радуга",
                "rose" to "роза",
                "seed" to "семя",
                "spring" to "весна",
                "waterfall" to "водопад"
            )
        )

        // HOME (40 words)
        addCategoryWords(
            WordCategory.HOME,
            listOf(
                "apartment" to "квартира",
                "balcony" to "балкон",
                "bathroom" to "ванная",
                "bed" to "кровать",
                "bedroom" to "спальня",
                "blanket" to "одеяло",
                "carpet" to "ковёр",
                "ceiling" to "потолок",
                "chair" to "стул",
                "clock" to "часы",
                "couch" to "диван",
                "curtain" to "занавеска",
                "desk" to "письменный стол",
                "door" to "дверь",
                "fence" to "забор",
                "floor" to "пол",
                "furniture" to "мебель",
                "garage" to "гараж",
                "house" to "дом",
                "key" to "ключ",
                "kitchen" to "кухня",
                "lamp" to "лампа",
                "light" to "свет",
                "living room" to "гостиная",
                "lock" to "замок",
                "mirror" to "зеркало",
                "oven" to "духовка",
                "picture" to "картина",
                "pillow" to "подушка",
                "refrigerator" to "холодильник",
                "roof" to "крыша",
                "room" to "комната",
                "shelf" to "полка",
                "shower" to "душ",
                "sink" to "раковина",
                "stairs" to "лестница",
                "table" to "стол",
                "toilet" to "туалет",
                "wall" to "стена",
                "window" to "окно"
            )
        )

        // WORK (35 words)
        addCategoryWords(
            WordCategory.WORK,
            listOf(
                "boss" to "начальник",
                "business" to "бизнес",
                "career" to "карьера",
                "client" to "клиент",
                "colleague" to "коллега",
                "company" to "компания",
                "computer" to "компьютер",
                "contract" to "контракт",
                "deadline" to "дедлайн",
                "email" to "электронная почта",
                "employee" to "сотрудник",
                "experience" to "опыт",
                "factory" to "фабрика",
                "interview" to "собеседование",
                "job" to "работа",
                "manager" to "менеджер",
                "meeting" to "встреча",
                "money" to "деньги",
                "office" to "офис",
                "payment" to "оплата",
                "phone" to "телефон",
                "plan" to "план",
                "price" to "цена",
                "printer" to "принтер",
                "problem" to "проблема",
                "product" to "продукт",
                "profit" to "прибыль",
                "project" to "проект",
                "report" to "отчёт",
                "salary" to "зарплата",
                "schedule" to "расписание",
                "skill" to "навык",
                "task" to "задача",
                "team" to "команда",
                "work" to "работа"
            )
        )

        // TRAVEL (35 words)
        addCategoryWords(
            WordCategory.TRAVEL,
            listOf(
                "adventure" to "приключение",
                "airplane" to "самолёт",
                "airport" to "аэропорт",
                "backpack" to "рюкзак",
                "beach" to "пляж",
                "boat" to "лодка",
                "border" to "граница",
                "bus" to "автобус",
                "camera" to "камера",
                "car" to "машина",
                "compass" to "компас",
                "country" to "страна",
                "cruise" to "круиз",
                "customs" to "таможня",
                "flight" to "рейс",
                "guide" to "гид",
                "hotel" to "отель",
                "journey" to "путешествие",
                "luggage" to "багаж",
                "map" to "карта",
                "museum" to "музей",
                "passport" to "паспорт",
                "restaurant" to "ресторан",
                "road" to "дорога",
                "sightseeing" to "осмотр достопримечательностей",
                "souvenir" to "сувенир",
                "station" to "станция",
                "suitcase" to "чемодан",
                "taxi" to "такси",
                "ticket" to "билет",
                "tour" to "тур",
                "tourist" to "турист",
                "train" to "поезд",
                "trip" to "поездка",
                "visa" to "виза"
            )
        )

        // BODY (30 words)
        addCategoryWords(
            WordCategory.BODY,
            listOf(
                "arm" to "рука",
                "back" to "спина",
                "blood" to "кровь",
                "bone" to "кость",
                "brain" to "мозг",
                "chest" to "грудь",
                "ear" to "ухо",
                "elbow" to "локоть",
                "eye" to "глаз",
                "face" to "лицо",
                "finger" to "палец",
                "foot" to "стопа",
                "hair" to "волосы",
                "hand" to "кисть",
                "head" to "голова",
                "heart" to "сердце",
                "knee" to "колено",
                "leg" to "нога",
                "lip" to "губа",
                "mouth" to "рот",
                "muscle" to "мышца",
                "neck" to "шея",
                "nose" to "нос",
                "shoulder" to "плечо",
                "skin" to "кожа",
                "stomach" to "желудок",
                "teeth" to "зубы",
                "throat" to "горло",
                "thumb" to "большой палец",
                "tongue" to "язык"
            )
        )

        // CLOTHES (30 words)
        addCategoryWords(
            WordCategory.CLOTHES,
            listOf(
                "belt" to "ремень",
                "boots" to "ботинки",
                "cap" to "кепка",
                "coat" to "пальто",
                "dress" to "платье",
                "glasses" to "очки",
                "gloves" to "перчатки",
                "hat" to "шляпа",
                "jacket" to "куртка",
                "jeans" to "джинсы",
                "pajamas" to "пижама",
                "pants" to "брюки",
                "pocket" to "карман",
                "ring" to "кольцо",
                "sandals" to "сандалии",
                "scarf" to "шарф",
                "shirt" to "рубашка",
                "shoes" to "обувь",
                "shorts" to "шорты",
                "skirt" to "юбка",
                "slippers" to "тапочки",
                "sneakers" to "кроссовки",
                "socks" to "носки",
                "suit" to "костюм",
                "sweater" to "свитер",
                "tie" to "галстук",
                "t-shirt" to "футболка",
                "umbrella" to "зонт",
                "uniform" to "униформа",
                "watch" to "часы"
            )
        )

        // ANIMALS (30 words)
        addCategoryWords(
            WordCategory.ANIMALS,
            listOf(
                "bear" to "медведь",
                "bird" to "птица",
                "butterfly" to "бабочка",
                "cat" to "кот",
                "chicken" to "курица",
                "cow" to "корова",
                "deer" to "олень",
                "dog" to "собака",
                "dolphin" to "дельфин",
                "duck" to "утка",
                "eagle" to "орёл",
                "elephant" to "слон",
                "fish" to "рыба",
                "fox" to "лиса",
                "frog" to "лягушка",
                "giraffe" to "жираф",
                "goat" to "коза",
                "horse" to "лошадь",
                "lion" to "лев",
                "monkey" to "обезьяна",
                "mouse" to "мышь",
                "owl" to "сова",
                "parrot" to "попугай",
                "penguin" to "пингвин",
                "pig" to "свинья",
                "rabbit" to "кролик",
                "shark" to "акула",
                "snake" to "змея",
                "tiger" to "тигр",
                "wolf" to "волк"
            )
        )

        // EMOTIONS (30 words)
        addCategoryWords(
            WordCategory.EMOTIONS,
            listOf(
                "anger" to "гнев",
                "anxiety" to "тревога",
                "boredom" to "скука",
                "calm" to "спокойствие",
                "confidence" to "уверенность",
                "confusion" to "замешательство",
                "courage" to "храбрость",
                "curiosity" to "любопытство",
                "disappointment" to "разочарование",
                "disgust" to "отвращение",
                "doubt" to "сомнение",
                "excitement" to "волнение",
                "fear" to "страх",
                "gratitude" to "благодарность",
                "guilt" to "вина",
                "happiness" to "счастье",
                "hope" to "надежда",
                "jealousy" to "ревность",
                "joy" to "радость",
                "kindness" to "доброта",
                "loneliness" to "одиночество",
                "love" to "любовь",
                "pride" to "гордость",
                "relief" to "облегчение",
                "sadness" to "грусть",
                "shame" to "стыд",
                "surprise" to "удивление",
                "sympathy" to "сочувствие",
                "trust" to "доверие",
                "worry" to "беспокойство"
            )
        )

        return words
    }
}
