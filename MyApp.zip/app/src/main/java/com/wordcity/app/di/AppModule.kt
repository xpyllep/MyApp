package com.wordcity.app.di

import android.content.Context
import androidx.room.Room
import com.wordcity.app.data.local.WordCityDatabase
import com.wordcity.app.data.local.dao.AchievementDao
import com.wordcity.app.data.local.dao.BuildingDao
import com.wordcity.app.data.local.dao.PlayerDao
import com.wordcity.app.data.local.dao.WordDao
import com.wordcity.app.data.repository.AchievementRepository
import com.wordcity.app.data.repository.BuildingRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.data.repository.WordRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Dependency injection module providing Database, DAOs, and Repositories across the application.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideWordCityDatabase(
        @ApplicationContext context: Context
    ): WordCityDatabase {
        return Room.databaseBuilder(
            context,
            WordCityDatabase::class.java,
            WordCityDatabase.DATABASE_NAME
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    @Provides
    fun provideWordDao(database: WordCityDatabase): WordDao {
        return database.wordDao()
    }

    @Provides
    fun providePlayerDao(database: WordCityDatabase): PlayerDao {
        return database.playerDao()
    }

    @Provides
    fun provideBuildingDao(database: WordCityDatabase): BuildingDao {
        return database.buildingDao()
    }

    @Provides
    fun provideAchievementDao(database: WordCityDatabase): AchievementDao {
        return database.achievementDao()
    }

    @Provides
    @Singleton
    fun provideWordRepository(wordDao: WordDao): WordRepository {
        return WordRepository(wordDao)
    }

    @Provides
    @Singleton
    fun providePlayerRepository(playerDao: PlayerDao): PlayerRepository {
        return PlayerRepository(playerDao)
    }

    @Provides
    @Singleton
    fun provideBuildingRepository(
        buildingDao: BuildingDao,
        playerDao: PlayerDao
    ): BuildingRepository {
        return BuildingRepository(buildingDao, playerDao)
    }

    @Provides
    @Singleton
    fun provideAchievementRepository(
        achievementDao: AchievementDao
    ): AchievementRepository {
        return AchievementRepository(achievementDao)
    }
}
