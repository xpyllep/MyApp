package com.wordcity.app.ui.city

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.domain.model.BuildingType
import com.wordcity.app.domain.model.costForLevel
import com.wordcity.app.domain.model.incomeForLevel
import com.wordcity.app.ui.components.CoinDisplay
import com.wordcity.app.ui.components.StreakIndicator
import com.wordcity.app.ui.components.XpBar
import com.wordcity.app.ui.theme.BuildingFactoryColor
import com.wordcity.app.ui.theme.BuildingHospitalColor
import com.wordcity.app.ui.theme.BuildingHouseColor
import com.wordcity.app.ui.theme.BuildingParkColor
import com.wordcity.app.ui.theme.BuildingSchoolColor
import com.wordcity.app.ui.theme.BuildingShopColor
import com.wordcity.app.ui.theme.BuildingStadiumColor
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.CoinGoldDark
import com.wordcity.app.ui.theme.CoinGoldLight
import com.wordcity.app.ui.theme.GrassGradientEnd
import com.wordcity.app.ui.theme.GrassGradientStart
import com.wordcity.app.ui.theme.SecondaryOrange
import com.wordcity.app.ui.theme.SecondaryOrangeDark
import com.wordcity.app.ui.theme.SkyGradientEnd
import com.wordcity.app.ui.theme.SkyGradientStart
import kotlinx.coroutines.flow.collectLatest

private const val GRID_SIZE = 6

/**
 * Resolves color palette for each building type.
 */
fun getBuildingColor(typeName: String): Color = when (typeName) {
    BuildingType.HOUSE.name -> BuildingHouseColor
    BuildingType.SHOP.name -> BuildingShopColor
    BuildingType.PARK.name -> BuildingParkColor
    BuildingType.FACTORY.name -> BuildingFactoryColor
    BuildingType.SCHOOL.name -> BuildingSchoolColor
    BuildingType.HOSPITAL.name -> BuildingHospitalColor
    BuildingType.STADIUM.name -> BuildingStadiumColor
    else -> Color(0xFF90A4AE)
}

/**
 * Main City screen displaying player statistics, an isometric-inspired 6x6 building grid,
 * passive income collection, and direct navigation to play quizzes.
 */
@Composable
fun CityScreen(
    onNavigateToGame: (category: String) -> Unit,
    onNavigateToShop: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: CityViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Play button pulse animation
    val playPulse = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        playPulse.animateTo(
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            SkyGradientStart,
                            SkyGradientEnd,
                            GrassGradientStart.copy(alpha = 0.5f),
                            GrassGradientEnd
                        ),
                        startY = 0f,
                        endY = 2200f
                    )
                )
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // TOP: Player Status Bar
                TopPlayerHeader(
                    player = uiState.player,
                    onCoinsClick = onNavigateToShop
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Passive Income Banner & Collector
                IncomeBanner(
                    totalIncome = uiState.totalIncome,
                    collectedAmount = uiState.collectedIncomeAmount,
                    onCollect = { viewModel.collectIncome() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // CENTER: City Grid Section
                Text(
                    text = "🏛️ Мой Мегаполис",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1B5E20)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                CityGridView(
                    buildings = uiState.buildings,
                    onCellClick = { x, y -> viewModel.onCellClicked(x, y) }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // BOTTOM: "Играть" Prominent Button
                Button(
                    onClick = { onNavigateToGame("ALL") },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(62.dp)
                        .scale(playPulse.value)
                        .shadow(elevation = 8.dp, shape = RoundedCornerShape(31.dp)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(31.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(SecondaryOrangeDark, SecondaryOrange, CoinGold)
                                ),
                                shape = RoundedCornerShape(31.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ИГРАТЬ",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    letterSpacing = 1.2.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }

            // Quick Build Dialog
            if (uiState.isBuildingDialogOpen && uiState.selectedCell != null) {
                QuickBuildDialog(
                    playerLevel = uiState.player?.level ?: 1,
                    playerCoins = uiState.player?.coins ?: 0,
                    onSelectBuilding = { type -> viewModel.purchaseBuilding(type) },
                    onDismiss = { viewModel.dismissDialogs() }
                )
            }

            // Upgrade Building Dialog
            if (uiState.isUpgradeDialogOpen && uiState.selectedBuilding != null) {
                UpgradeBuildingDialog(
                    building = uiState.selectedBuilding!!,
                    playerCoins = uiState.player?.coins ?: 0,
                    onUpgrade = { viewModel.upgradeCurrentBuilding() },
                    onDismiss = { viewModel.dismissDialogs() }
                )
            }
        }
    }
}

/**
 * Top header containing player level, rank, XP progression, coins, and streak.
 */
@Composable
private fun TopPlayerHeader(
    player: com.wordcity.app.data.local.entity.PlayerEntity?,
    onCoinsClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.94f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🏙️ WordCity",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StreakIndicator(streak = player?.currentStreak ?: 0)
                    CoinDisplay(
                        coins = player?.coins ?: 0,
                        onClick = onCoinsClick
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Player XP and Rank Progress
            XpBar(
                currentXp = player?.xp ?: 0,
                level = player?.level ?: 1
            )
        }
    }
}

/**
 * Floating banner indicating passive coin earnings with a "Collect" action.
 */
@Composable
private fun IncomeBanner(
    totalIncome: Int,
    collectedAmount: Int?,
    onCollect: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.92f),
        shadowElevation = 3.dp,
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .clickable { onCollect() }
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "💰 Доход: $totalIncome 🪙/мин",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2E7D32)
                )
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(CoinGoldDark, CoinGold)
                        )
                    )
                    .clickable { onCollect() }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "Собрать",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }

    // Floating collected text indicator
    AnimatedVisibility(
        visible = collectedAmount != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { 20 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -20 })
    ) {
        Text(
            text = "+$collectedAmount 🪙",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Black,
                color = CoinGoldDark
            ),
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

/**
 * 6x6 2D City Grid with horizontal and vertical scrollability.
 */
@Composable
private fun CityGridView(
    buildings: List<BuildingEntity>,
    onCellClick: (x: Int, y: Int) -> Unit
) {
    val buildingsMap = remember(buildings) {
        buildings.associateBy { it.gridX to it.gridY }
    }

    Card(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .shadow(elevation = 6.dp, shape = RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9).copy(alpha = 0.95f))
    ) {
        Box(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (y in 0 until GRID_SIZE) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (x in 0 until GRID_SIZE) {
                            val building = buildingsMap[x to y]
                            CityGridCell(
                                building = building,
                                onClick = { onCellClick(x, y) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Individual cell on the 6x6 grid.
 */
@Composable
private fun CityGridCell(
    building: BuildingEntity?,
    onClick: () -> Unit
) {
    val cellSize = 54.dp

    if (building != null) {
        val buildingType = BuildingType.fromString(building.type)
        val emoji = buildingType?.emoji ?: "🏢"
        val bgColor = getBuildingColor(building.type)

        Box(
            modifier = Modifier
                .size(cellSize)
                .shadow(elevation = 3.dp, shape = RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(bgColor)
                .border(1.5.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = emoji,
                    fontSize = 22.sp
                )
                // Level pill badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "L${building.level}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        )
                    )
                }
            }
        }
    } else {
        // Empty cell with "+" button
        Box(
            modifier = Modifier
                .size(cellSize)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.65f))
                .border(
                    width = 1.dp,
                    color = Color(0xFFA5D6A7),
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Построить",
                tint = Color(0xFF66BB6A),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Dialog for selecting a new building to construct on an empty grid slot.
 */
@Composable
private fun QuickBuildDialog(
    playerLevel: Int,
    playerCoins: Int,
    onSelectBuilding: (BuildingType) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🏗️ Новое здание",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BuildingType.entries.forEach { type ->
                    val isLevelUnlocked = playerLevel >= type.requiredLevel
                    val canAfford = playerCoins >= type.baseCost
                    val isAvailable = isLevelUnlocked && canAfford

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = isAvailable) { onSelectBuilding(type) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isAvailable) {
                                getBuildingColor(type.name).copy(alpha = 0.2f)
                            } else {
                                Color(0xFFEEEEEE)
                            }
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = type.emoji,
                                    fontSize = 28.sp,
                                    modifier = Modifier.padding(end = 10.dp)
                                )
                                Column {
                                    Text(
                                        text = type.displayName,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "+${type.baseIncome} 🪙/мин",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Color(0xFF2E7D32)
                                        )
                                    )
                                    if (!isLevelUnlocked) {
                                        Text(
                                            text = "С уровня ${type.requiredLevel}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "${type.baseCost} 🪙",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Dialog for viewing and upgrading an existing building.
 */
@Composable
private fun UpgradeBuildingDialog(
    building: BuildingEntity,
    playerCoins: Int,
    onUpgrade: () -> Unit,
    onDismiss: () -> Unit
) {
    val type = BuildingType.fromString(building.type) ?: BuildingType.HOUSE
    val nextLevel = building.level + 1
    val upgradeCost = type.costForLevel(nextLevel)
    val nextIncome = type.incomeForLevel(nextLevel)
    val currentIncome = type.incomeForLevel(building.level)
    val canAfford = playerCoins >= upgradeCost

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = type.emoji, fontSize = 28.sp, modifier = Modifier.padding(end = 8.dp))
                Column {
                    Text(
                        text = type.displayName,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Уровень ${building.level}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Текущий доход: $currentIncome 🪙/мин",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Доход на уровне $nextLevel: $nextIncome 🪙/мин",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Стоимость улучшения: $upgradeCost 🪙",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onUpgrade,
                enabled = canAfford,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SecondaryOrange
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.Upgrade,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Улучшить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )
}
