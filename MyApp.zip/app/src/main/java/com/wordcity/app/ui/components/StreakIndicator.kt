package com.wordcity.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.StreakOrange
import com.wordcity.app.ui.theme.StreakOrangeDark
import com.wordcity.app.ui.theme.StreakOrangeLight

/**
 * Calculates current streak multiplier based on consecutive correct quiz answers.
 */
fun getStreakMultiplier(streak: Int): Float = when {
    streak >= 20 -> 5.0f
    streak >= 10 -> 3.0f
    streak >= 5 -> 2.0f
    streak >= 3 -> 1.5f
    else -> 1.0f
}

/**
 * Streak indicator component featuring animated fire icon, current streak count,
 * and active score multiplier badge.
 */
@Composable
fun StreakIndicator(
    streak: Int,
    modifier: Modifier = Modifier,
    showContainer: Boolean = true
) {
    val scaleAnim = remember { Animatable(1f) }
    val flamePulse = remember { Animatable(1f) }

    LaunchedEffect(streak) {
        if (streak > 0) {
            scaleAnim.animateTo(
                targetValue = 1f,
                animationSpec = keyframes {
                    durationMillis = 400
                    1.25f at 160 using FastOutSlowInEasing
                    0.95f at 280
                    1.0f at 400
                }
            )
        }
    }

    LaunchedEffect(streak >= 3) {
        if (streak >= 3) {
            flamePulse.animateTo(
                targetValue = 1.15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        } else {
            flamePulse.snapTo(1f)
        }
    }

    val multiplier = getStreakMultiplier(streak)

    val content = @Composable {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.scale(scaleAnim.value)
        ) {
            Text(
                text = "🔥",
                fontSize = 18.sp,
                modifier = Modifier
                    .padding(end = 4.dp)
                    .scale(flamePulse.value)
            )
            AnimatedCounter(
                targetValue = streak,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = StreakOrangeDark
                )
            )

            if (multiplier > 1.0f) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(StreakOrange, CoinGold)
                            )
                        )
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    val multiplierText = if (multiplier % 1.0f == 0.0f) {
                        "x${multiplier.toInt()}"
                    } else {
                        "x$multiplier"
                    }
                    Text(
                        text = multiplierText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }

    if (showContainer) {
        Box(
            modifier = modifier
                .shadow(elevation = 2.dp, shape = RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.White,
                            StreakOrangeLight.copy(alpha = 0.45f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = StreakOrange.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
    } else {
        Box(modifier = modifier) {
            content()
        }
    }
}
