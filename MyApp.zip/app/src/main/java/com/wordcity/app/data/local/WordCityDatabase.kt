package com.wordcity.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.wordcity.app.data.local.dao.AchievementDao
import com.wordcity.app.data.local.dao.BuildingDao
import com.wordcity.app.data.local.dao.PlayerDao
import com.wordcity.app.data.local.dao.WordDao
import com.wordcity.app.data.local.entity.AchievementEntity
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.data.local.entity.PlayerEntity
import com.wordcity.app.data.local.entity.WordEntity

/**
 * Main Room database for WordCity.
 */
@Database(
    entities = [
        WordEntity::class,
        PlayerEntity::class,
        BuildingEntity::class,
        AchievementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WordCityDatabase : RoomDatabase() {

    abstract fun wordDao(): WordDao
    abstract fun playerDao(): PlayerDao
    abstract fun buildingDao(): BuildingDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        const val DATABASE_NAME = "wordcity.db"
    }
}
