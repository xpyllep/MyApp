package com.wordcity.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.wordcity.app.data.local.entity.BuildingEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for city buildings.
 */
@Dao
interface BuildingDao {

    @Query("SELECT * FROM buildings ORDER BY id ASC")
    fun getAllBuildings(): Flow<List<BuildingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuilding(building: BuildingEntity): Long

    @Update
    suspend fun updateBuilding(building: BuildingEntity)

    @Query("SELECT COUNT(*) FROM buildings")
    fun getBuildingCount(): Flow<Int>

    @Query("SELECT * FROM buildings WHERE gridX = :gridX AND gridY = :gridY LIMIT 1")
    suspend fun getBuildingAt(gridX: Int, gridY: Int): BuildingEntity?

    @Query("SELECT * FROM buildings WHERE id = :id LIMIT 1")
    suspend fun getBuildingById(id: Int): BuildingEntity?
}
