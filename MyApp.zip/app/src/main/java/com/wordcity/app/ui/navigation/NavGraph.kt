package com.wordcity.app.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.wordcity.app.ui.city.CityScreen
import com.wordcity.app.ui.dictionary.DictionaryScreen
import com.wordcity.app.ui.game.GameScreen
import com.wordcity.app.ui.profile.ProfileScreen
import com.wordcity.app.ui.shop.ShopScreen
import com.wordcity.app.ui.theme.PrimaryBlue

/**
 * Root navigation host containing the Scaffold with bottom navigation bar
 * and all destination routes in WordCity.
 */
@Composable
fun WordCityNavGraph(
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Screen.bottomNavScreens.forEach { screen ->
                    val isSelected = when (screen) {
                        is Screen.Game -> currentRoute?.startsWith("game") == true
                        else -> currentRoute == screen.route
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            val targetRoute = if (screen is Screen.Game) {
                                Screen.Game.createRoute()
                            } else {
                                screen.route
                            }

                            navController.navigate(targetRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryBlue,
                            selectedTextColor = PrimaryBlue,
                            indicatorColor = PrimaryBlue.copy(alpha = 0.12f),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.City.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // City Screen (Main Home)
            composable(route = Screen.City.route) {
                CityScreen(
                    onNavigateToGame = { category ->
                        navController.navigate(Screen.Game.createRoute(category))
                    },
                    onNavigateToShop = {
                        navController.navigate(Screen.Shop.route)
                    }
                )
            }

            // Game Quiz Screen
            composable(
                route = Screen.Game.route,
                arguments = listOf(
                    navArgument(Screen.Game.ARG_CATEGORY) {
                        type = NavType.StringType
                        defaultValue = Screen.Game.DEFAULT_CATEGORY
                    }
                )
            ) {
                GameScreen(
                    onNavigateBack = {
                        if (!navController.popBackStack()) {
                            navController.navigate(Screen.City.route)
                        }
                    },
                    onNavigateToCity = {
                        navController.navigate(Screen.City.route) {
                            popUpTo(Screen.City.route) { inclusive = false }
                        }
                    }
                )
            }

            // Shop Screen
            composable(route = Screen.Shop.route) {
                ShopScreen()
            }

            // Dictionary Screen
            composable(route = Screen.Dictionary.route) {
                DictionaryScreen()
            }

            // Profile Screen
            composable(route = Screen.Profile.route) {
                ProfileScreen()
            }
        }
    }
}
