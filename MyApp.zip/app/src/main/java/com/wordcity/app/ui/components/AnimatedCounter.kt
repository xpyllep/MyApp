package com.wordcity.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight

/**
 * Reusable animated counter that smoothly transitions between integer values.
 */
@Composable
fun AnimatedCounter(
    targetValue: Int,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
    color: Color = Color.Unspecified,
    prefix: String = "",
    suffix: String = ""
) {
    val animatedValue by animateIntAsState(
        targetValue = targetValue,
        animationSpec = tween(
            durationMillis = 600,
            easing = FastOutSlowInEasing
        ),
        label = "AnimatedCounter"
    )

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (prefix.isNotEmpty()) {
            Text(
                text = prefix,
                style = style,
                color = color
            )
        }

        // Split digits to animate individual character rolls
        val countString = animatedValue.toString()
        for (char in countString) {
            DigitRoll(
                char = char,
                style = style,
                color = color
            )
        }

        if (suffix.isNotEmpty()) {
            Text(
                text = suffix,
                style = style,
                color = color
            )
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun DigitRoll(
    char: Char,
    style: TextStyle,
    color: Color
) {
    AnimatedContent(
        targetState = char,
        transitionSpec = {
            if (targetState > initialState) {
                slideInVertically { height -> -height } togetherWith
                        slideOutVertically { height -> height }
            } else {
                slideInVertically { height -> height } togetherWith
                        slideOutVertically { height -> -height }
            }
        },
        label = "DigitRoll"
    ) { targetChar ->
        Text(
            text = targetChar.toString(),
            style = style,
            color = color,
            softWrap = false
        )
    }
}
