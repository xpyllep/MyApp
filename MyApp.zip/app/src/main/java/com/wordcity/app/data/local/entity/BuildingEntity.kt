package com.wordcity.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing a placed building on the city grid.
 *
 * @property id Auto-generated building instance identifier
 * @property type BuildingType name (HOUSE, SHOP, PARK, FACTORY, SCHOOL, HOSPITAL, STADIUM)
 * @property level Current upgrade level of the building (starts at 1)
 * @property gridX X-coordinate on the district city grid
 * @property gridY Y-coordinate on the district city grid
 * @property purchasedAt Epoch timestamp when the building was purchased
 */
@Entity(tableName = "buildings")
data class BuildingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val type: String,
    val level: Int = 1,
    val gridX: Int,
    val gridY: Int,
    val purchasedAt: Long = System.currentTimeMillis()
)
