package com.wordcity.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing an achievement tracked in the local database.
 *
 * @property id Unique key matching Achievement constants
 * @property name Title of the achievement
 * @property description Task required to unlock
 * @property emoji Representative emoji icon
 * @property unlocked Whether unlocked by the player
 * @property unlockedAt Epoch timestamp when unlocked, 0 if still locked
 * @property progress Current quantified progress toward the target
 * @property target Required target value to unlock
 */
@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val unlocked: Boolean = false,
    val unlockedAt: Long = 0L,
    val progress: Int = 0,
    val target: Int = 1
)
