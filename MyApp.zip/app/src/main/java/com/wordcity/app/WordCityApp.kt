package com.wordcity.app

import android.app.Application
import com.wordcity.app.data.repository.AchievementRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.data.repository.WordRepository
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Main application class for WordCity.
 * Configured with Hilt for dependency injection and handles initial database pre-population.
 */
@HiltAndroidApp
class WordCityApp : Application() {

    @Inject
    lateinit var wordRepository: WordRepository

    @Inject
    lateinit var playerRepository: PlayerRepository

    @Inject
    lateinit var achievementRepository: AchievementRepository

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        initializeDatabase()
    }

    private fun initializeDatabase() {
        applicationScope.launch {
            wordRepository.initializeWordsIfEmpty()
            playerRepository.initializePlayer()
            playerRepository.updateLastPlayed()
            achievementRepository.initializeAchievements()
        }
    }
}
