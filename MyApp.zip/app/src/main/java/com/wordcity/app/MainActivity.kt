package com.wordcity.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.wordcity.app.ui.navigation.WordCityNavGraph
import com.wordcity.app.ui.theme.WordCityTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Main entrance activity for WordCity application.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WordCityTheme {
                WordCityNavGraph()
            }
        }
    }
}
