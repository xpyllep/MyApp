package com.wordcity.app.domain.model

/**
 * Word categories available in WordCity.
 *
 * @property displayName Russian localized display name of the category
 * @property emoji Representative emoji icon
 * @property requiredLevel Minimum player level required to unlock this category
 * @property districtColor Color hex for the district corresponding to this category
 */
enum class WordCategory(
    val displayName: String,
    val emoji: String,
    val requiredLevel: Int,
    val districtColor: Long
) {
    FOOD("Еда", "🍔", 1, 0xFFFF6B35),
    NATURE("Природа", "🌿", 1, 0xFF2ECC71),
    HOME("Дом", "🏠", 1, 0xFF3498DB),
    WORK("Работа", "💼", 5, 0xFF9B59B6),
    TRAVEL("Путешествия", "✈️", 5, 0xFFE74C3C),
    BODY("Тело", "🧍", 10, 0xFFE67E22),
    CLOTHES("Одежда", "👕", 10, 0xFF1ABC9C),
    ANIMALS("Животные", "🐾", 15, 0xFFF39C12),
    EMOTIONS("Эмоции", "😊", 15, 0xFFFF69B4);

    companion object {
        fun fromString(name: String): WordCategory? {
            return entries.find { it.name.equals(name, ignoreCase = true) }
        }
    }
}
