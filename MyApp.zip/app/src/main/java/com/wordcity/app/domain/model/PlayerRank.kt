package com.wordcity.app.domain.model

/**
 * Player rank hierarchy based on player level.
 *
 * @property displayName Russian localized title of the rank
 * @property emoji Representative emoji icon
 * @property minLevel Minimum player level required to obtain this rank
 */
enum class PlayerRank(
    val displayName: String,
    val emoji: String,
    val minLevel: Int
) {
    NEWBIE("Новичок", "🌱", 1),
    STUDENT("Студент", "📖", 6),
    EXPERT("Знаток", "🎓", 16),
    MASTER("Мастер", "👑", 31),
    PROFESSOR("Профессор", "🏆", 50)
}

/**
 * Determines the player's rank corresponding to their current level.
 */
fun getRankForLevel(level: Int): PlayerRank = PlayerRank.entries.last { it.minLevel <= level }

/**
 * Determines the XP required to reach the next level from [level].
 */
fun xpForLevel(level: Int): Int = (100 * level * 1.5).toInt()
