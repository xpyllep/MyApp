package com.wordcity.app.ui.dictionary

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordcity.app.data.local.entity.WordEntity
import com.wordcity.app.data.repository.WordRepository
import com.wordcity.app.domain.model.WordCategory
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Available sorting options for dictionary vocabulary list.
 */
enum class SortOption(val displayName: String, val emoji: String) {
    ALPHABETICAL("По алфавиту (A-Z)", "🔤"),
    CATEGORY("По категориям", "📁"),
    PROGRESS("По прогрессу", "📈")
}

/**
 * UI State for the Word Dictionary screen.
 *
 * @property allWords Entire dictionary dataset from Room
 * @property filteredWords Filtered and sorted subset currently displayed
 * @property selectedCategory Category filter, null for all categories
 * @property searchQuery Text filter searching English word or Russian translation
 * @property showLearned null = all words, true = mastered only, false = in-progress only
 * @property sortBy Current sorting criteria
 * @property isLoading Whether words are being loaded from database
 */
data class DictionaryUiState(
    val allWords: List<WordEntity> = emptyList(),
    val filteredWords: List<WordEntity> = emptyList(),
    val selectedCategory: WordCategory? = null,
    val searchQuery: String = "",
    val showLearned: Boolean? = null,
    val sortBy: SortOption = SortOption.ALPHABETICAL,
    val isLoading: Boolean = false
)

/**
 * ViewModel handling dictionary search, multi-criteria filtering, and word list sorting.
 */
@HiltViewModel
class DictionaryViewModel @Inject constructor(
    private val wordRepository: WordRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DictionaryUiState(isLoading = true))
    val uiState: StateFlow<DictionaryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            wordRepository.initializeWordsIfEmpty()
            wordRepository.getAllWords().collect { words ->
                _uiState.update { current ->
                    val filtered = applyFilterAndSort(
                        words = words,
                        category = current.selectedCategory,
                        query = current.searchQuery,
                        showLearned = current.showLearned,
                        sort = current.sortBy
                    )
                    current.copy(
                        allWords = words,
                        filteredWords = filtered,
                        isLoading = false
                    )
                }
            }
        }
    }

    /**
     * Filters words by specific category or clears filter when null.
     */
    fun setCategory(category: WordCategory?) {
        _uiState.update { current ->
            val newCategory = if (current.selectedCategory == category) null else category
            val filtered = applyFilterAndSort(
                words = current.allWords,
                category = newCategory,
                query = current.searchQuery,
                showLearned = current.showLearned,
                sort = current.sortBy
            )
            current.copy(selectedCategory = newCategory, filteredWords = filtered)
        }
    }

    /**
     * Filters words matching English spelling or Russian translation.
     */
    fun setSearchQuery(query: String) {
        _uiState.update { current ->
            val filtered = applyFilterAndSort(
                words = current.allWords,
                category = current.selectedCategory,
                query = query,
                showLearned = current.showLearned,
                sort = current.sortBy
            )
            current.copy(searchQuery = query, filteredWords = filtered)
        }
    }

    /**
     * Filters words by mastered status (null = all, true = learned, false = learning).
     */
    fun setShowLearned(show: Boolean?) {
        _uiState.update { current ->
            val newShowLearned = if (current.showLearned == show) null else show
            val filtered = applyFilterAndSort(
                words = current.allWords,
                category = current.selectedCategory,
                query = current.searchQuery,
                showLearned = newShowLearned,
                sort = current.sortBy
            )
            current.copy(showLearned = newShowLearned, filteredWords = filtered)
        }
    }

    /**
     * Changes active sorting strategy.
     */
    fun setSortBy(sort: SortOption) {
        _uiState.update { current ->
            val filtered = applyFilterAndSort(
                words = current.allWords,
                category = current.selectedCategory,
                query = current.searchQuery,
                showLearned = current.showLearned,
                sort = sort
            )
            current.copy(sortBy = sort, filteredWords = filtered)
        }
    }

    /**
     * Resets all search and filter parameters to default.
     */
    fun resetFilters() {
        _uiState.update { current ->
            val filtered = applyFilterAndSort(
                words = current.allWords,
                category = null,
                query = "",
                showLearned = null,
                sort = SortOption.ALPHABETICAL
            )
            current.copy(
                selectedCategory = null,
                searchQuery = "",
                showLearned = null,
                sortBy = SortOption.ALPHABETICAL,
                filteredWords = filtered
            )
        }
    }

    private fun applyFilterAndSort(
        words: List<WordEntity>,
        category: WordCategory?,
        query: String,
        showLearned: Boolean?,
        sort: SortOption
    ): List<WordEntity> {
        var result = words

        if (category != null) {
            result = result.filter { it.category.equals(category.name, ignoreCase = true) }
        }

        if (query.isNotBlank()) {
            val trimmed = query.trim().lowercase()
            result = result.filter {
                it.english.lowercase().contains(trimmed) ||
                        it.russian.lowercase().contains(trimmed)
            }
        }

        if (showLearned != null) {
            result = result.filter { it.learned == showLearned }
        }

        return when (sort) {
            SortOption.ALPHABETICAL -> result.sortedBy { it.english.lowercase() }
            SortOption.CATEGORY -> result.sortedWith(
                compareBy<WordEntity> { it.category }
                    .thenBy { it.english.lowercase() }
            )
            SortOption.PROGRESS -> result.sortedWith(
                compareByDescending<WordEntity> { it.learned }
                    .thenByDescending { it.correctCount }
                    .thenBy { it.english.lowercase() }
            )
        }
    }
}
