package com.wordcity.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors
val PrimaryBlue = Color(0xFF1A73E8)
val PrimaryBlueLight = Color(0xFFD2E3FC)
val PrimaryBlueDark = Color(0xFF0D47A1)

// Secondary Colors
val SecondaryOrange = Color(0xFFFF6D00)
val SecondaryOrangeLight = Color(0xFFFFE0B2)
val SecondaryOrangeDark = Color(0xFFE65100)

// Tertiary Colors
val TertiaryGreen = Color(0xFF00C853)
val TertiaryGreenLight = Color(0xFFB9F6CA)
val TertiaryGreenDark = Color(0xFF00701A)

// Neutral & Background Colors - Light
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F3F4)
val OnSurfaceLight = Color(0xFF202124)
val OnSurfaceVariantLight = Color(0xFF5F6368)

// Neutral & Background Colors - Dark
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2D2D2D)
val OnSurfaceDark = Color(0xFFE8EAED)
val OnSurfaceVariantDark = Color(0xFF9AA0A6)

// Error Colors
val ErrorRed = Color(0xFFD93025)
val ErrorContainerLight = Color(0xFFFCE8E6)
val ErrorContainerDark = Color(0xFF5C1D18)

// Game Accent Colors
val CoinGold = Color(0xFFFFB300)
val CoinGoldLight = Color(0xFFFFF9C4)
val CoinGoldDark = Color(0xFFFFA000)

val XpPurple = Color(0xFF9C27B0)
val XpPurpleLight = Color(0xFFE1BEE7)
val XpPurpleDark = Color(0xFF6A1B9A)

val StreakOrange = Color(0xFFFF5722)
val StreakOrangeLight = Color(0xFFFFCCBC)
val StreakOrangeDark = Color(0xFFBF360C)

val CorrectGreen = Color(0xFF00C853)
val CorrectGreenLight = Color(0xFFE8F5E9)

val IncorrectRed = Color(0xFFE53935)
val IncorrectRedLight = Color(0xFFFFEBEE)

// Timer Indicators
val TimerGreen = Color(0xFF4CAF50)
val TimerYellow = Color(0xFFFFB300)
val TimerRed = Color(0xFFF44336)

// Building Type Colors
val BuildingHouseColor = Color(0xFFFFA726)
val BuildingShopColor = Color(0xFF26A69A)
val BuildingParkColor = Color(0xFF66BB6A)
val BuildingFactoryColor = Color(0xFF78909C)
val BuildingSchoolColor = Color(0xFF5C6BC0)
val BuildingHospitalColor = Color(0xFFEF5350)
val BuildingStadiumColor = Color(0xFFAB47BC)

// Environment & City Gradients
val SkyGradientStart = Color(0xFF4FC3F7)
val SkyGradientEnd = Color(0xFFE1F5FE)
val GrassGradientStart = Color(0xFF81C784)
val GrassGradientEnd = Color(0xFF388E3C)
val CardOverlay = Color(0x1AFFFFFF)
val GridBorderColor = Color(0x20000000)
