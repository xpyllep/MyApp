package com.wordcity.app.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordcity.app.data.local.SeedData
import com.wordcity.app.data.local.entity.AchievementEntity
import com.wordcity.app.data.local.entity.PlayerEntity
import com.wordcity.app.data.repository.AchievementRepository
import com.wordcity.app.data.repository.BuildingRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.data.repository.WordRepository
import com.wordcity.app.domain.model.PlayerRank
import com.wordcity.app.domain.model.getRankForLevel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for the Player Profile screen.
 *
 * @property player Current player profile and gameplay stats
 * @property rank Progression rank title and badge
 * @property achievements List of achievements with current progress
 * @property totalBuildings Count of constructed buildings
 * @property totalLearnedWords Mastered words count
 * @property accuracy Overall quiz answering accuracy percentage
 * @property avatarOptions Available emoji avatars to select from
 * @property showAvatarPicker Whether the avatar picker bottom sheet or dialog is visible
 */
data class ProfileUiState(
    val player: PlayerEntity = SeedData.getInitialPlayer(),
    val rank: PlayerRank = PlayerRank.NEWBIE,
    val achievements: List<AchievementEntity> = emptyList(),
    val totalBuildings: Int = 0,
    val totalLearnedWords: Int = 0,
    val accuracy: Float = 0f,
    val avatarOptions: List<String> = ProfileViewModel.AVATAR_OPTIONS,
    val showAvatarPicker: Boolean = false
)

/**
 * ViewModel managing player profile data, statistics, achievements, and avatar customization.
 */
@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val achievementRepository: AchievementRepository,
    private val buildingRepository: BuildingRepository,
    private val wordRepository: WordRepository
) : ViewModel() {

    companion object {
        val AVATAR_OPTIONS = listOf(
            "👨‍🎓", "👩‍🎓", "🧑‍💻", "👨‍🏫", "👩‍🏫",
            "🦸‍♂️", "🦸‍♀️", "🧙‍♂️", "🧙‍♀️", "👨‍🚀"
        )
    }

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            // Ensure achievements are initialized
            achievementRepository.initializeAchievements()

            combine(
                playerRepository.getPlayer(),
                achievementRepository.getAllAchievements(),
                buildingRepository.getBuildingCount(),
                wordRepository.getTotalLearnedCount()
            ) { player, achievements, buildingCount, learnedCount ->
                val totalAnswers = player.totalCorrect + player.totalIncorrect
                val accuracy = if (totalAnswers > 0) {
                    (player.totalCorrect.toFloat() / totalAnswers.toFloat()) * 100f
                } else {
                    0f
                }
                val rank = getRankForLevel(player.level)

                ProfileUiState(
                    player = player,
                    rank = rank,
                    achievements = achievements,
                    totalBuildings = buildingCount,
                    totalLearnedWords = learnedCount,
                    accuracy = accuracy,
                    avatarOptions = AVATAR_OPTIONS,
                    showAvatarPicker = _uiState.value.showAvatarPicker
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    /**
     * Updates player avatar by index within [AVATAR_OPTIONS].
     */
    fun changeAvatar(avatarId: Int) {
        if (avatarId in AVATAR_OPTIONS.indices) {
            viewModelScope.launch {
                playerRepository.updateAvatar(avatarId)
                _uiState.update { it.copy(showAvatarPicker = false) }
            }
        }
    }

    /**
     * Toggles visibility of the avatar picker modal.
     */
    fun toggleAvatarPicker() {
        _uiState.update { it.copy(showAvatarPicker = !it.showAvatarPicker) }
    }

    /**
     * Dismisses the avatar picker modal.
     */
    fun dismissAvatarPicker() {
        _uiState.update { it.copy(showAvatarPicker = false) }
    }
}
