package com.wordcity.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.CoinGoldDark
import com.wordcity.app.ui.theme.CoinGoldLight

/**
 * Display for player's coin balance with subtle bounce animation when value increases.
 */
@Composable
fun CoinDisplay(
    coins: Int,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    showContainer: Boolean = true
) {
    val scaleAnim = remember { Animatable(1f) }

    LaunchedEffect(coins) {
        if (coins > 0) {
            scaleAnim.animateTo(
                targetValue = 1f,
                animationSpec = keyframes {
                    durationMillis = 350
                    1.2f at 150 using FastOutSlowInEasing
                    1.0f at 350
                }
            )
        }
    }

    val content = @Composable {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.scale(scaleAnim.value)
        ) {
            Text(
                text = "🪙",
                fontSize = 18.sp,
                modifier = Modifier.padding(end = 4.dp)
            )
            AnimatedCounter(
                targetValue = coins,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = CoinGoldDark
                )
            )
        }
    }

    if (showContainer) {
        Box(
            modifier = modifier
                .shadow(elevation = 2.dp, shape = RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.White,
                            CoinGoldLight.copy(alpha = 0.4f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = CoinGold.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(16.dp)
                )
                .then(
                    if (onClick != null) {
                        Modifier.clickable { onClick() }
                    } else {
                        Modifier
                    }
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
    } else {
        Box(
            modifier = modifier.then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
        ) {
            content()
        }
    }
}
