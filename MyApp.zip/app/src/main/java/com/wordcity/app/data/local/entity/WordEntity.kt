package com.wordcity.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing an English-Russian vocabulary word.
 *
 * @property id Unique auto-generated identifier
 * @property english English word or phrase
 * @property russian Russian translation
 * @property category Category key (matching WordCategory names)
 * @property learned Whether the player has mastered this word (e.g. >= 3 correct answers)
 * @property correctCount Total count of correct answers in quizzes
 * @property incorrectCount Total count of incorrect answers in quizzes
 * @property lastShownAt Epoch timestamp when the word was last presented in a quiz
 */
@Entity(tableName = "words")
data class WordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val english: String,
    val russian: String,
    val category: String,
    val learned: Boolean = false,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0,
    val lastShownAt: Long = 0L
)
