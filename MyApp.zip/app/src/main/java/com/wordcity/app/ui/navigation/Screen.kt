package com.wordcity.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Sealed hierarchy of screens in WordCity.
 */
sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object City : Screen(
        route = "city",
        title = "Город",
        icon = Icons.Filled.Home
    )

    data object Game : Screen(
        route = "game/{category}",
        title = "Играть",
        icon = Icons.Filled.PlayArrow
    ) {
        const val ARG_CATEGORY = "category"
        const val DEFAULT_CATEGORY = "ALL"

        fun createRoute(category: String = DEFAULT_CATEGORY): String {
            return "game/$category"
        }
    }

    data object Shop : Screen(
        route = "shop",
        title = "Магазин",
        icon = Icons.Filled.ShoppingCart
    )

    data object Dictionary : Screen(
        route = "dictionary",
        title = "Словарь",
        icon = Icons.Filled.MenuBook
    )

    data object Profile : Screen(
        route = "profile",
        title = "Профиль",
        icon = Icons.Filled.Person
    )

    companion object {
        /**
         * Top-level screens shown in the bottom navigation bar.
         */
        val bottomNavScreens = listOf(
            City,
            Game,
            Shop,
            Dictionary,
            Profile
        )
    }
}
