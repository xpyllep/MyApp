package com.wordcity.app.ui.shop

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.domain.model.BuildingType
import com.wordcity.app.domain.model.costForLevel
import com.wordcity.app.domain.model.incomeForLevel
import com.wordcity.app.ui.components.CoinDisplay
import com.wordcity.app.ui.theme.BuildingFactoryColor
import com.wordcity.app.ui.theme.BuildingHospitalColor
import com.wordcity.app.ui.theme.BuildingHouseColor
import com.wordcity.app.ui.theme.BuildingParkColor
import com.wordcity.app.ui.theme.BuildingSchoolColor
import com.wordcity.app.ui.theme.BuildingShopColor
import com.wordcity.app.ui.theme.BuildingStadiumColor
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.CoinGoldDark
import com.wordcity.app.ui.theme.CoinGoldLight
import com.wordcity.app.ui.theme.CorrectGreen
import com.wordcity.app.ui.theme.PrimaryBlue

/**
 * Returns custom brand color mapped to the specified [BuildingType].
 */
fun getBuildingTypeColor(type: BuildingType): Color = when (type) {
    BuildingType.HOUSE -> BuildingHouseColor
    BuildingType.SHOP -> BuildingShopColor
    BuildingType.PARK -> BuildingParkColor
    BuildingType.FACTORY -> BuildingFactoryColor
    BuildingType.SCHOOL -> BuildingSchoolColor
    BuildingType.HOSPITAL -> BuildingHospitalColor
    BuildingType.STADIUM -> BuildingStadiumColor
}

/**
 * Main Shop screen supporting building catalog purchases, city grid placement, and upgrades.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(
    modifier: Modifier = Modifier,
    viewModel: ShopViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🏪",
                            fontSize = 24.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = "Магазин зданий",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                    }
                },
                actions = {
                    CoinDisplay(
                        coins = state.playerCoins,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PrimaryBlue,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = PrimaryBlue,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Купить 🏗️",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium
                            )
                        )
                    }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Улучшить ⬆️",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                            if (state.ownedBuildings.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(PrimaryBlue.copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${state.ownedBuildings.size}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = PrimaryBlue,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                )
            }

            when (selectedTabIndex) {
                0 -> BuildingsBuyCatalog(
                    buildings = state.availableBuildings,
                    playerLevel = state.playerLevel,
                    playerCoins = state.playerCoins,
                    onBuyClick = viewModel::selectBuildingToBuy
                )
                1 -> BuildingsUpgradeCatalog(
                    ownedBuildings = state.ownedBuildings,
                    playerCoins = state.playerCoins,
                    onUpgradeClick = viewModel::selectBuildingToUpgrade
                )
            }
        }
    }

    if (state.showPlacementDialog && state.selectedBuilding != null) {
        PlacementGridDialog(
            buildingType = state.selectedBuilding!!,
            ownedBuildings = state.ownedBuildings,
            onCellSelected = viewModel::placeBuildingAt,
            onDismiss = viewModel::dismissPlacementDialog
        )
    }

    if (state.showUpgradeDialog && state.selectedOwnedBuilding != null) {
        UpgradeConfirmationDialog(
            building = state.selectedOwnedBuilding!!,
            playerCoins = state.playerCoins,
            onConfirmUpgrade = viewModel::upgradeBuilding,
            onDismiss = viewModel::dismissUpgradeDialog
        )
    }
}

/**
 * Grid catalog displaying buildings available for purchase.
 */
@Composable
private fun BuildingsBuyCatalog(
    buildings: List<BuildingType>,
    playerLevel: Int,
    playerCoins: Int,
    onBuyClick: (BuildingType) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(buildings, key = { it.name }) { building ->
            BuildingBuyCard(
                building = building,
                playerLevel = playerLevel,
                playerCoins = playerCoins,
                onBuyClick = { onBuyClick(building) }
            )
        }
    }
}

/**
 * Individual card representation for a building available in the shop catalog.
 */
@Composable
private fun BuildingBuyCard(
    building: BuildingType,
    playerLevel: Int,
    playerCoins: Int,
    onBuyClick: () -> Unit
) {
    val isLevelLocked = playerLevel < building.requiredLevel
    val canAfford = playerCoins >= building.baseCost
    val buildingColor = getBuildingTypeColor(building)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(if (isLevelLocked) 1.dp else 4.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                colors = if (isLevelLocked) {
                    listOf(Color.LightGray.copy(alpha = 0.5f), Color.LightGray.copy(alpha = 0.3f))
                } else {
                    listOf(buildingColor.copy(alpha = 0.8f), buildingColor.copy(alpha = 0.3f))
                }
            ),
            width = if (isLevelLocked) 1.dp else 2.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Building Icon with dynamic halo
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(
                        if (isLevelLocked) {
                            Color.LightGray.copy(alpha = 0.2f)
                        } else {
                            buildingColor.copy(alpha = 0.15f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isLevelLocked) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = building.emoji,
                            fontSize = 32.sp,
                            modifier = Modifier.alpha(0.35f)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Заблокировано",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    Text(
                        text = building.emoji,
                        fontSize = 38.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Building Name
            Text(
                text = building.displayName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = if (isLevelLocked) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Passive Income Tag
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CorrectGreen.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "+${building.baseIncome} 🪙/мин",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = CorrectGreen
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Level Requirement / Cost Details
            if (isLevelLocked) {
                Text(
                    text = "Требуется ур. ${building.requiredLevel}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.error
                    ),
                    textAlign = TextAlign.Center
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(text = "🪙", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${building.baseCost}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Purchase Button
            Button(
                onClick = onBuyClick,
                enabled = !isLevelLocked,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buildingColor,
                    disabledContainerColor = Color.LightGray.copy(alpha = 0.4f)
                ),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                Text(
                    text = if (isLevelLocked) "Закрыто" else "Купить",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isLevelLocked) Color.DarkGray.copy(alpha = 0.5f) else Color.White
                    )
                )
            }
        }
    }
}

/**
 * Catalog displaying buildings already constructed by the player, with upgrade capabilities.
 */
@Composable
private fun BuildingsUpgradeCatalog(
    ownedBuildings: List<BuildingEntity>,
    playerCoins: Int,
    onUpgradeClick: (BuildingEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (ownedBuildings.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "🏗️", fontSize = 56.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Город пока пуст!",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Перейдите во вкладку «Купить», чтобы построить своё первое здание и получать пассивный доход.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(ownedBuildings, key = { it.id }) { building ->
                BuildingUpgradeCard(
                    building = building,
                    playerCoins = playerCoins,
                    onUpgradeClick = { onUpgradeClick(building) }
                )
            }
        }
    }
}

/**
 * Card for an individual owned building with upgrade details and action button.
 */
@Composable
private fun BuildingUpgradeCard(
    building: BuildingEntity,
    playerCoins: Int,
    onUpgradeClick: () -> Unit
) {
    val buildingType = BuildingType.fromString(building.type) ?: BuildingType.HOUSE
    val buildingColor = getBuildingTypeColor(buildingType)
    val isMaxLevel = building.level >= 3
    val nextLevel = building.level + 1
    val upgradeCost = if (!isMaxLevel) buildingType.costForLevel(nextLevel) else 0
    val canAfford = playerCoins >= upgradeCost
    val currentIncome = buildingType.incomeForLevel(building.level)
    val nextIncome = buildingType.incomeForLevel(nextLevel)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(3.dp, RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                colors = listOf(buildingColor.copy(alpha = 0.7f), buildingColor.copy(alpha = 0.2f))
            ),
            width = 1.5.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon with level badge
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(buildingColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = buildingType.emoji,
                    fontSize = 32.sp
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .clip(CircleShape)
                        .background(buildingColor)
                        .padding(horizontal = 6.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "Ур. ${building.level}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = buildingType.displayName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${building.gridX + 1}, ${building.gridY + 1})",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Income preview
                if (isMaxLevel) {
                    Text(
                        text = "Доход: +$currentIncome 🪙/мин (МАКС)",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = CorrectGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "+$currentIncome",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Text(
                            text = " ➔ ",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = CorrectGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "+$nextIncome 🪙/мин",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = CorrectGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Цена улучшения: ",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Text(
                            text = "$upgradeCost 🪙",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action button
            if (isMaxLevel) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.LightGray.copy(alpha = 0.25f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "МАКС ⭐",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray
                        )
                    )
                }
            } else {
                Button(
                    onClick = onUpgradeClick,
                    enabled = canAfford,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryBlue
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Upgrade,
                        contentDescription = "Улучшить",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Улучшить",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

/**
 * Interactive City Grid dialog allowing player to tap an empty cell (4x4) to construct their building.
 */
@Composable
private fun PlacementGridDialog(
    buildingType: BuildingType,
    ownedBuildings: List<BuildingEntity>,
    onCellSelected: (gridX: Int, gridY: Int) -> Unit,
    onDismiss: () -> Unit
) {
    val gridSize = 4
    val buildingColor = getBuildingTypeColor(buildingType)
    var selectedCoords by remember { androidx.compose.runtime.mutableStateOf<Pair<Int, Int>?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = buildingType.emoji, fontSize = 28.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Размещение здания",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = buildingType.displayName,
                        style = MaterialTheme.typography.bodySmall.copy(color = buildingColor, fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Выберите свободную клетку на карте города (4 × 4):",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // 4x4 City Grid
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFE8F5E9))
                        .border(2.dp, Color(0xFFA5D6A7), RoundedCornerShape(16.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (row in 0 until gridSize) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (col in 0 until gridSize) {
                                val occupiedBuilding = ownedBuildings.find { it.gridX == col && it.gridY == row }
                                val isSelected = selectedCoords == Pair(col, row)

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when {
                                                occupiedBuilding != null -> Color.White.copy(alpha = 0.9f)
                                                isSelected -> buildingColor.copy(alpha = 0.35f)
                                                else -> Color.White.copy(alpha = 0.6f)
                                            }
                                        )
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = when {
                                                isSelected -> buildingColor
                                                occupiedBuilding != null -> Color.Gray.copy(alpha = 0.3f)
                                                else -> Color(0xFF81C784)
                                            },
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable(enabled = occupiedBuilding == null) {
                                            selectedCoords = Pair(col, row)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (occupiedBuilding != null) {
                                        val existingType = BuildingType.fromString(occupiedBuilding.type)
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = existingType?.emoji ?: "🏢",
                                                fontSize = 18.sp
                                            )
                                            Text(
                                                text = "Ур.${occupiedBuilding.level}",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.DarkGray
                                                )
                                            )
                                        }
                                    } else if (isSelected) {
                                        Text(text = buildingType.emoji, fontSize = 20.sp)
                                    } else {
                                        Text(
                                            text = "+",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                color = Color(0xFF66BB6A),
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                selectedCoords?.let { (x, y) ->
                    Text(
                        text = "Выбрана клетка: Ряд ${y + 1}, Колонка ${x + 1}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlue
                        )
                    )
                } ?: Text(
                    text = "Нажмите на клетку со знаком «+»",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedCoords?.let { (x, y) ->
                        onCellSelected(x, y)
                    }
                },
                enabled = selectedCoords != null,
                colors = ButtonDefaults.buttonColors(containerColor = buildingColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Построить (${buildingType.baseCost} 🪙)",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Отмена")
            }
        }
    )
}

/**
 * Confirmation dialog before upgrading a building.
 */
@Composable
private fun UpgradeConfirmationDialog(
    building: BuildingEntity,
    playerCoins: Int,
    onConfirmUpgrade: () -> Unit,
    onDismiss: () -> Unit
) {
    val buildingType = BuildingType.fromString(building.type) ?: BuildingType.HOUSE
    val buildingColor = getBuildingTypeColor(buildingType)
    val nextLevel = building.level + 1
    val upgradeCost = buildingType.costForLevel(nextLevel)
    val canAfford = playerCoins >= upgradeCost
    val currentIncome = buildingType.incomeForLevel(building.level)
    val nextIncome = buildingType.incomeForLevel(nextLevel)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = buildingType.emoji, fontSize = 28.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Улучшение здания",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Вы действительно хотите улучшить «${buildingType.displayName}»?",
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Уровень:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "${building.level} ➔ $nextLevel",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Доход монет:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "+$currentIncome ➔ +$nextIncome 🪙/мин",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CorrectGreen
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Стоимость:", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "$upgradeCost 🪙",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }
                }

                if (!canAfford) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Вам не хватает ${upgradeCost - playerCoins} монет!",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmUpgrade,
                enabled = canAfford,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Улучшить ($upgradeCost 🪙)", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Отмена")
            }
        }
    )
}
