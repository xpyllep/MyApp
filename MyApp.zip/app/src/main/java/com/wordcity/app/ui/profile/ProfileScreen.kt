package com.wordcity.app.ui.profile

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wordcity.app.data.local.entity.AchievementEntity
import com.wordcity.app.ui.components.CoinDisplay
import com.wordcity.app.ui.components.XpBar
import com.wordcity.app.ui.theme.CoinGold
import com.wordcity.app.ui.theme.CoinGoldDark
import com.wordcity.app.ui.theme.CorrectGreen
import com.wordcity.app.ui.theme.PrimaryBlue
import com.wordcity.app.ui.theme.PrimaryBlueLight
import com.wordcity.app.ui.theme.SecondaryOrange
import com.wordcity.app.ui.theme.StreakOrange
import com.wordcity.app.ui.theme.XpPurple
import com.wordcity.app.ui.theme.XpPurpleDark
import java.util.Locale

/**
 * Player Profile screen showing statistics, avatar customization, XP rank, and achievements.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "👤",
                            fontSize = 24.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = "Профиль игрока",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                    }
                },
                actions = {
                    CoinDisplay(
                        coins = state.player.coins,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header Section: Avatar, Name, Rank, XP Bar
            item {
                ProfileHeader(
                    state = state,
                    onAvatarClick = viewModel::toggleAvatarPicker
                )
            }

            // Stats Section
            item {
                Text(
                    text = "📊 Статистика",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                StatsGrid(state = state)
            }

            // Achievements Section
            item {
                val unlockedCount = state.achievements.count { it.unlocked }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🏆 Достижения",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(CoinGold.copy(alpha = 0.18f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$unlockedCount / ${state.achievements.size}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = CoinGoldDark
                            )
                        )
                    }
                }
            }

            items(
                count = state.achievements.size,
                key = { index -> state.achievements[index].id }
            ) { index ->
                AchievementCard(achievement = state.achievements[index])
            }
        }
    }

    if (state.showAvatarPicker) {
        AvatarPickerDialog(
            currentAvatarId = state.player.avatarId,
            avatarOptions = state.avatarOptions,
            onAvatarSelected = viewModel::changeAvatar,
            onDismiss = viewModel::dismissAvatarPicker
        )
    }
}

/**
 * Top profile header with large animated avatar, level badge, rank badge, and full XP progression bar.
 */
@Composable
private fun ProfileHeader(
    state: ProfileUiState,
    onAvatarClick: () -> Unit
) {
    val currentAvatar = state.avatarOptions.getOrElse(state.player.avatarId) { "👨‍🎓" }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(PrimaryBlueLight.copy(alpha = 0.8f), Color.White)
            ),
            width = 1.5.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Interactive Avatar with Edit badge
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(PrimaryBlueLight, PrimaryBlue.copy(alpha = 0.2f))
                        )
                    )
                    .border(3.dp, PrimaryBlue, CircleShape)
                    .clickable { onAvatarClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentAvatar,
                    fontSize = 50.sp
                )
                // Edit icon overlay badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(PrimaryBlue)
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Изменить аватар",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Player Name
            Text(
                text = state.player.name,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Rank & Level Badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Rank Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(XpPurple.copy(alpha = 0.12f))
                        .border(1.dp, XpPurple.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = state.rank.emoji, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = state.rank.displayName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = XpPurpleDark
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Level Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(SecondaryOrange.copy(alpha = 0.15f))
                        .border(1.dp, SecondaryOrange.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Уровень ${state.player.level}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SecondaryOrange
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // XP Progress Bar component
            XpBar(
                currentXp = state.player.xp,
                level = state.player.level,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * 2-column grid representing gameplay statistics.
 */
@Composable
private fun StatsGrid(state: ProfileUiState) {
    val accuracyFormatted = String.format(Locale.US, "%.1f%%", state.accuracy)

    val stats = listOf(
        StatItem(
            emoji = "📚",
            label = "Слов выучено",
            value = "${state.totalLearnedWords}",
            accentColor = PrimaryBlue
        ),
        StatItem(
            emoji = "✅",
            label = "Правильных ответов",
            value = "${state.player.totalCorrect}",
            accentColor = CorrectGreen
        ),
        StatItem(
            emoji = "🎯",
            label = "Точность",
            value = accuracyFormatted,
            accentColor = Color(0xFF00ACC1)
        ),
        StatItem(
            emoji = "🔥",
            label = "Лучшая серия",
            value = "${state.player.bestStreak}",
            accentColor = StreakOrange
        ),
        StatItem(
            emoji = "🏗️",
            label = "Зданий построено",
            value = "${state.totalBuildings}",
            accentColor = Color(0xFF7E57C2)
        ),
        StatItem(
            emoji = "📅",
            label = "Дней подряд",
            value = "${state.player.consecutiveDays}",
            accentColor = SecondaryOrange
        ),
        StatItem(
            emoji = "💰",
            label = "Всего монет",
            value = "${state.player.coins}",
            accentColor = CoinGoldDark
        ),
        StatItem(
            emoji = "⭐",
            label = "Всего XP",
            value = "${state.player.xp}",
            accentColor = XpPurple
        )
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (i in stats.indices step 2) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(item = stats[i], modifier = Modifier.weight(1f))
                if (i + 1 < stats.size) {
                    StatCard(item = stats[i + 1], modifier = Modifier.weight(1f))
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

private data class StatItem(
    val emoji: String,
    val label: String,
    val value: String,
    val accentColor: Color
)

@Composable
private fun StatCard(
    item: StatItem,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.shadow(2.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(item.accentColor.copy(alpha = 0.4f), Color.Transparent)
            ),
            width = 1.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(item.accentColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = item.emoji, fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = item.value,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = item.accentColor
                    )
                )
                Text(
                    text = item.label,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * Achievement card supporting subtle glowing effect when unlocked, and progress bar when in-progress.
 */
@Composable
private fun AchievementCard(
    achievement: AchievementEntity,
    modifier: Modifier = Modifier
) {
    val isUnlocked = achievement.unlocked
    val progress = achievement.progress
    val target = achievement.target
    val progressRatio = if (target > 0) (progress.toFloat() / target.toFloat()).coerceIn(0f, 1f) else 0f

    val infiniteTransition = rememberInfiniteTransition(label = "glowTransition")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(if (isUnlocked) 3.dp else 1.dp, RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            }
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = if (isUnlocked) {
                Brush.horizontalGradient(
                    listOf(
                        CoinGold.copy(alpha = glowAlpha),
                        CoinGoldDark.copy(alpha = glowAlpha * 0.7f)
                    )
                )
            } else {
                Brush.linearGradient(
                    listOf(Color.LightGray.copy(alpha = 0.4f), Color.LightGray.copy(alpha = 0.2f))
                )
            },
            width = if (isUnlocked) 1.5.dp else 1.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Achievement Emoji
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (isUnlocked) {
                            CoinGold.copy(alpha = 0.18f)
                        } else {
                            Color.LightGray.copy(alpha = 0.25f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = achievement.emoji,
                    fontSize = 28.sp
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Name, Description, and Progress
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = achievement.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    )
                    if (isUnlocked) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Выполнено",
                            tint = CorrectGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = achievement.description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                if (isUnlocked) {
                    Text(
                        text = "Выполнено! 🎉",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CorrectGreen
                        )
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LinearProgressIndicator(
                            progress = { progressRatio },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = PrimaryBlue,
                            trackColor = Color(0xFFE0E0E0),
                            strokeCap = StrokeCap.Round
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "$progress / $target",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Avatar selection modal displaying emoji options in a clean grid.
 */
@Composable
private fun AvatarPickerDialog(
    currentAvatarId: Int,
    avatarOptions: List<String>,
    onAvatarSelected: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Выберите аватар",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Выберите персонажа, который представляет вас в WordCity:",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(avatarOptions) { index, emoji ->
                        val isSelected = index == currentAvatarId
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isSelected) PrimaryBlueLight else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) PrimaryBlue else Color.Transparent,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { onAvatarSelected(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 28.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Закрыть")
            }
        }
    )
}
