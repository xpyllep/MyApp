package com.wordcity.app.data.repository

import com.wordcity.app.data.local.SeedData
import com.wordcity.app.data.local.dao.AchievementDao
import com.wordcity.app.data.local.entity.AchievementEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository handling achievement initialization, tracking, and unlocks.
 */
@Singleton
class AchievementRepository @Inject constructor(
    private val achievementDao: AchievementDao
) {

    /**
     * Flow of all achievements with their current progress and unlock status.
     */
    fun getAllAchievements(): Flow<List<AchievementEntity>> {
        return achievementDao.getAllAchievements()
    }

    /**
     * Initializes default achievements in the database if not present.
     */
    suspend fun initializeAchievements() {
        if (achievementDao.getAchievementCount() == 0) {
            achievementDao.insertAchievements(SeedData.getInitialAchievements())
        }
    }

    /**
     * Updates absolute progress for a specific achievement and unlocks it if target is reached.
     *
     * @param achievementId Unique achievement identifier
     * @param progress New absolute progress value
     * @return true if the achievement was newly unlocked during this call, false otherwise
     */
    suspend fun updateProgress(achievementId: String, progress: Int): Boolean {
        val achievement = achievementDao.getAchievement(achievementId) ?: return false
        if (achievement.unlocked) {
            return false
        }

        val newProgress = maxOf(achievement.progress, progress)
        val isUnlocked = newProgress >= achievement.target
        val unlockedAt = if (isUnlocked) System.currentTimeMillis() else 0L

        achievementDao.updateAchievement(
            achievement.copy(
                progress = newProgress,
                unlocked = isUnlocked,
                unlockedAt = unlockedAt
            )
        )

        return isUnlocked
    }

    /**
     * Increments the current progress of an achievement by a given delta.
     *
     * @param achievementId Unique achievement identifier
     * @param delta Amount to add to current progress
     * @return true if newly unlocked, false otherwise
     */
    suspend fun incrementProgress(achievementId: String, delta: Int = 1): Boolean {
        val achievement = achievementDao.getAchievement(achievementId) ?: return false
        if (achievement.unlocked) {
            return false
        }
        return updateProgress(achievementId, achievement.progress + delta)
    }

    /**
     * Flow emitting the count of completed/unlocked achievements.
     */
    fun getUnlockedCount(): Flow<Int> {
        return achievementDao.getUnlockedCount()
    }
}
