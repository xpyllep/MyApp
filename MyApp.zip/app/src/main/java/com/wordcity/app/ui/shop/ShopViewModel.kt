package com.wordcity.app.ui.shop

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordcity.app.data.local.entity.BuildingEntity
import com.wordcity.app.data.repository.BuildingRepository
import com.wordcity.app.data.repository.PlayerRepository
import com.wordcity.app.domain.model.BuildingType
import com.wordcity.app.domain.model.costForLevel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for the City Shop screen.
 *
 * @property playerCoins Current coin balance of the player
 * @property playerLevel Current player level
 * @property availableBuildings Catalog of all building types
 * @property ownedBuildings List of buildings currently placed in the city
 * @property selectedBuilding Building type currently selected for purchase/placement
 * @property showPlacementDialog Controls visibility of the city grid placement dialog
 * @property showUpgradeDialog Controls visibility of the building upgrade dialog
 * @property selectedOwnedBuilding Building instance selected for upgrade
 * @property message Feedback message for snackbar notifications
 */
data class ShopUiState(
    val playerCoins: Int = 0,
    val playerLevel: Int = 1,
    val availableBuildings: List<BuildingType> = BuildingType.entries.toList(),
    val ownedBuildings: List<BuildingEntity> = emptyList(),
    val selectedBuilding: BuildingType? = null,
    val showPlacementDialog: Boolean = false,
    val showUpgradeDialog: Boolean = false,
    val selectedOwnedBuilding: BuildingEntity? = null,
    val message: String? = null
)

/**
 * ViewModel managing the building shop, placement coordinates, and building upgrades.
 */
@HiltViewModel
class ShopViewModel @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val buildingRepository: BuildingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ShopUiState())
    val uiState: StateFlow<ShopUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                playerRepository.getPlayer(),
                buildingRepository.getAllBuildings()
            ) { player, buildings ->
                Pair(player, buildings)
            }.collect { (player, buildings) ->
                _uiState.update { current ->
                    current.copy(
                        playerCoins = player.coins,
                        playerLevel = player.level,
                        ownedBuildings = buildings
                    )
                }
            }
        }
    }

    /**
     * Selects a building type from the catalog to purchase.
     * Validates player level and coin balance before opening placement grid.
     */
    fun selectBuildingToBuy(type: BuildingType) {
        val currentState = _uiState.value
        if (currentState.playerLevel < type.requiredLevel) {
            _uiState.update {
                it.copy(message = "Требуется уровень ${type.requiredLevel} для постройки!")
            }
            return
        }
        if (currentState.playerCoins < type.baseCost) {
            _uiState.update {
                it.copy(message = "Недостаточно монет! Нужно ${type.baseCost} 🪙")
            }
            return
        }
        _uiState.update {
            it.copy(
                selectedBuilding = type,
                showPlacementDialog = true
            )
        }
    }

    /**
     * Confirms building placement at target grid coordinates.
     */
    fun placeBuildingAt(gridX: Int, gridY: Int) {
        val buildingToPlace = _uiState.value.selectedBuilding ?: return
        viewModelScope.launch {
            val success = buildingRepository.purchaseBuilding(
                type = buildingToPlace.name,
                gridX = gridX,
                gridY = gridY,
                cost = buildingToPlace.baseCost
            )
            if (success) {
                _uiState.update {
                    it.copy(
                        selectedBuilding = null,
                        showPlacementDialog = false,
                        message = "Здание «${buildingToPlace.displayName}» успешно построено! 🎉"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        message = "Не удалось построить: клетка занята или недостаточно монет."
                    )
                }
            }
        }
    }

    /**
     * Selects an existing owned building to view upgrade details.
     */
    fun selectBuildingToUpgrade(building: BuildingEntity) {
        if (building.level >= 3) {
            _uiState.update {
                it.copy(message = "Здание уже достигло максимального уровня (3)!")
            }
            return
        }
        _uiState.update {
            it.copy(
                selectedOwnedBuilding = building,
                showUpgradeDialog = true
            )
        }
    }

    /**
     * Executes building upgrade to next level if affordable.
     */
    fun upgradeBuilding() {
        val building = _uiState.value.selectedOwnedBuilding ?: return
        val buildingType = BuildingType.fromString(building.type) ?: run {
            _uiState.update { it.copy(showUpgradeDialog = false) }
            return
        }

        if (building.level >= 3) {
            _uiState.update {
                it.copy(
                    showUpgradeDialog = false,
                    message = "Здание уже достигло максимального уровня (3)!"
                )
            }
            return
        }

        val nextLevel = building.level + 1
        val upgradeCost = buildingType.costForLevel(nextLevel)

        if (_uiState.value.playerCoins < upgradeCost) {
            _uiState.update {
                it.copy(message = "Недостаточно монет! Требуется $upgradeCost 🪙")
            }
            return
        }

        viewModelScope.launch {
            val success = buildingRepository.upgradeBuilding(building.id, upgradeCost)
            if (success) {
                _uiState.update {
                    it.copy(
                        selectedOwnedBuilding = null,
                        showUpgradeDialog = false,
                        message = "«${buildingType.displayName}» улучшен до уровня $nextLevel! ⬆️"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        message = "Ошибка при улучшении здания. Попробуйте снова."
                    )
                }
            }
        }
    }

    /**
     * Closes the grid placement dialog without purchasing.
     */
    fun dismissPlacementDialog() {
        _uiState.update {
            it.copy(
                showPlacementDialog = false,
                selectedBuilding = null
            )
        }
    }

    /**
     * Closes the building upgrade dialog.
     */
    fun dismissUpgradeDialog() {
        _uiState.update {
            it.copy(
                showUpgradeDialog = false,
                selectedOwnedBuilding = null
            )
        }
    }

    /**
     * Clears snackbar message.
     */
    fun dismissMessage() {
        _uiState.update { it.copy(message = null) }
    }
}
