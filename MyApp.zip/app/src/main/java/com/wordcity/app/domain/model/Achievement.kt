package com.wordcity.app.domain.model

/**
 * Domain model representing an in-game achievement with progress tracking.
 *
 * @property id Unique identifier for the achievement
 * @property name Russian localized title of the achievement
 * @property description Russian localized description of the goal
 * @property emoji Icon representation for the achievement
 * @property target Numerical goal value required to unlock
 * @property progress Current progress towards the target
 * @property unlocked Whether the achievement has been unlocked
 * @property unlockedAt Timestamp (epoch millis) when achievement was unlocked, or 0 if locked
 */
data class Achievement(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val target: Int,
    val progress: Int = 0,
    val unlocked: Boolean = false,
    val unlockedAt: Long = 0L
) {
    /**
     * Progress ratio normalized between 0.0 and 1.0.
     */
    val progressPercentage: Float
        get() = if (target > 0) (progress.toFloat() / target.toFloat()).coerceIn(0f, 1f) else 0f

    companion object {
        const val FIRST_STEPS = "FIRST_STEPS"
        const val MARATHONER = "MARATHONER"
        const val POLYGLOT = "POLYGLOT"
        const val ARCHITECT = "ARCHITECT"
        const val MAYOR = "MAYOR"
        const val INFALLIBLE = "INFALLIBLE"
        const val CENTURION = "CENTURION"
        const val STREAK_MASTER = "STREAK_MASTER"
        const val DEDICATED = "DEDICATED"
        const val RICH = "RICH"

        /**
         * List of default definitions for all in-game achievements.
         */
        val PREDEFINED_ACHIEVEMENTS: List<Achievement> = listOf(
            Achievement(
                id = FIRST_STEPS,
                name = "Первые шаги",
                description = "Выучите 10 слов",
                emoji = "👣",
                target = 10
            ),
            Achievement(
                id = CENTURION,
                name = "Центурион",
                description = "Выучите 100 слов",
                emoji = "💯",
                target = 100
            ),
            Achievement(
                id = POLYGLOT,
                name = "Полиглот",
                description = "Выучите 500 слов",
                emoji = "🌍",
                target = 500
            ),
            Achievement(
                id = STREAK_MASTER,
                name = "Мастер серий",
                description = "Достигните серии из 20 правильных ответов",
                emoji = "🔥",
                target = 20
            ),
            Achievement(
                id = INFALLIBLE,
                name = "Непогрешимый",
                description = "Достигните серии из 50 правильных ответов",
                emoji = "⚡",
                target = 50
            ),
            Achievement(
                id = ARCHITECT,
                name = "Архитектор",
                description = "Постройте 10 зданий",
                emoji = "🏗️",
                target = 10
            ),
            Achievement(
                id = MAYOR,
                name = "Мэр",
                description = "Заполните целый район зданиями",
                emoji = "🏛️",
                target = 1
            ),
            Achievement(
                id = MARATHONER,
                name = "Марафонец",
                description = "Занимайтесь 7 дней подряд",
                emoji = "🏃",
                target = 7
            ),
            Achievement(
                id = DEDICATED,
                name = "Преданный",
                description = "Занимайтесь 30 дней подряд",
                emoji = "🌟",
                target = 30
            ),
            Achievement(
                id = RICH,
                name = "Богач",
                description = "Накопите 10 000 монет",
                emoji = "💰",
                target = 10000
            )
        )
    }
}
