package com.wordcity.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.wordcity.app.data.local.entity.PlayerEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for player profile, currency, and stats.
 */
@Dao
interface PlayerDao {

    @Query("SELECT * FROM player WHERE id = 1 LIMIT 1")
    fun getPlayer(): Flow<PlayerEntity?>

    @Query("SELECT * FROM player WHERE id = 1 LIMIT 1")
    suspend fun getPlayerSync(): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Query("UPDATE player SET coins = coins + :amount WHERE id = 1")
    suspend fun addCoins(amount: Int)

    @Query("UPDATE player SET xp = xp + :amount WHERE id = 1")
    suspend fun addXp(amount: Int)

    @Query("UPDATE player SET currentStreak = :streak, bestStreak = :bestStreak WHERE id = 1")
    suspend fun updateStreak(streak: Int, bestStreak: Int)

    @Query("UPDATE player SET level = :level WHERE id = 1")
    suspend fun updateLevel(level: Int)
}
