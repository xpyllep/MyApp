package com.wordcity.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.wordcity.app.data.local.entity.WordEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for vocabulary words in Room database.
 */
@Dao
interface WordDao {

    @Query("SELECT * FROM words WHERE category = :category ORDER BY id ASC")
    fun getWordsByCategory(category: String): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE category = :category AND id != :excludeId ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomWordsForQuiz(category: String, excludeId: Int, limit: Int): List<WordEntity>

    @Query("SELECT * FROM words WHERE category = :category ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomWord(category: String): WordEntity?

    @Query("SELECT * FROM words WHERE id = :id LIMIT 1")
    suspend fun getWordById(id: Int): WordEntity?

    @Update
    suspend fun updateWord(word: WordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<WordEntity>)

    @Query("SELECT * FROM words WHERE learned = 1 ORDER BY lastShownAt DESC")
    fun getLearnedWords(): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE correctCount > 0 AND learned = 0 ORDER BY lastShownAt ASC")
    fun getWordsForReview(): Flow<List<WordEntity>>

    @Query("SELECT COUNT(*) FROM words WHERE learned = 1")
    fun getTotalLearnedCount(): Flow<Int>

    @Query("SELECT * FROM words ORDER BY id ASC")
    fun getAllWords(): Flow<List<WordEntity>>

    @Query("SELECT COUNT(*) FROM words")
    suspend fun getWordCount(): Int
}
